# Pipeline Audit & Redesign — Analysis Companion

Companion to the eight tested modules. Each section: what's wrong today, why it matters, what the module does about it, and how to keep testing it. Numbers are estimates with stated assumptions — recalibrate every one of them against your 20-article pilot before trusting them.

---

## 1. Ingestion & Chunking (`text_cleaning.py`)

**Audit of current `chunk_text_by_paragraphs`.** Three real failure modes: (a) it splits on `\n\n`, so single-paragraph HTML dumps become one chunk that blows the context window; (b) it counts characters, not tokens — a 2,500-char chunk of CJK or emoji-laden text can be 2–3× the token budget you think it is; (c) it happily cuts a quote in half at a paragraph boundary, and half a quote is unusable evidence.

**Redesign.** Clean → sentence-split → token-budgeted packing with sentence overlap. The overlap (default 2 sentences) is the co-occurrence guarantee: evidence spanning a boundary appears whole in at least one chunk, so tag pairs that co-occur across a boundary are still seen together. For evidence that habitually runs longer than 3 sentences, raise `overlap_sentences` — cost is linear. Cleaning is deliberately conservative: a kept nav item costs tokens; a deleted evidence sentence costs the report. Non-English and RTL content is detected and *routed*, not silently processed — Scout's extraction quality off-English is unvalidated, so those articles go to a separate lane (multilingual model, or exclusion with a logged count that belongs in your methods note).

**Testing.** The suite covers boilerplate/JS/CSS stripping, abbreviation-safe splitting, budget compliance, overlap presence, no-mid-word cuts, an 800-word pathological sentence, and RTL detection. Add corpus-specific regression cases whenever a real article breaks something — the dirty-input zoo only grows.

---

## 2. JSON Repair (`json_repair.py`)

**Risks.** The dangerous failure isn't unparseable JSON (visible, retryable) — it's *silently wrong* repair: a truncated `evidence_quotes` string closed mid-quote parses fine and yields half a quote. Two mitigations: every repair is **recorded** in `RepairResult.repairs` (checkpointed per chunk, so repair *rate* is a drift metric), and the verbatim-substring check in `extraction_prompt.verify_quotes()` catches truncated or hallucinated quotes downstream regardless of how they got mangled.

**Design decisions.** Duplicate keys keep the *first* occurrence (models emit the real value, then hallucinate a duplicate). Extra keys like `"explanation"` are dropped at schema time, not treated as failures. `E_UNKNOWN_TAG`/`E_EMPTY_TAGS` are review-routing signals, not hard failures — the chunk still ships, flagged. Missing required tags: I recommend **against** your "second focused LLM call to infer the missing field" option — a model that omitted `tags` once is being asked to guess under pressure, and an inferred tag is exactly the laundered judgment your trust layer exists to prevent. Route `E_MISSING_FIELD` to human review instead; at your observed ~1% malformation rate that's ~180 articles of triage, mostly resolved by the retry loop first. The retry loop mutates the prompt (reminder → strict mode), max 2 retries; each retry consumes rate-controller retry budget (§6) so malformation storms can't cascade.

**Testing.** Eight malformation classes covered. Maintain a growing corpus of *real* failures from your checkpoint DB (`chunks_needing_repair`) as regression fixtures — real model damage is weirder than synthetic damage.

---

## 3. Neo4j Safety & Performance (`neo4j_loader.py`)

**Injection audit.** String-formatted Cypher in a pipeline that ingests LLM output means model-generated entity IDs flow into query text — a backtick or quote in an ID breaks queries at best, executes at worst. Fix is absolute: all *values* travel as `$parameters`. The one thing Cypher can't parameterize is labels/relationship types, so those come from hard-coded whitelists; a non-whitelisted label raises, a non-whitelisted relationship degrades to `UNKNOWN` with the original preserved in properties. Nothing from a model ever becomes query syntax.

**Batch sizing.** For a 32 GB-host local Neo4j (heap ~8–12 GB, page cache ~12–16 GB), the constraint is transaction state, not row count. Target ~3 MB of serialized payload per transaction (`dynamic_batches` sizes by bytes, floor 100 / ceiling 2,000 rows): at 20–100 entities per article averaging 300–3,000 bytes each, that's roughly 1,000–5,000 mixed rows per batch — large enough to amortize, small enough that a transaction never approaches heap pressure. Byte-sizing matters because "rows" hides a 50× size spread.

**Integrity.** Nodes `MERGE` on `(label, id)` with per-label uniqueness constraints (the dedupe backbone across chunk extractions of the same article); descriptions and source files accumulate as arrays on re-encounter rather than overwriting. Edges `MATCH` both endpoints, never `MERGE` them — a bad edge cannot materialize a phantom, property-less node that would slip past your epistemic-status whitelist. Dangling references are counted and reported; they are your contract-rejection shadows.

**Testing.** Offline: batch-sizing behavior and injection blocking (covered). Integration: docker Neo4j, load a synthetic article twice, assert node count unchanged, descriptions array grew, dangling count matches planted bad edges.

---

## 4. Audit-Trail Immutability (`audit_verifier.py`)

**The honest audit answer: yes.** A plain hash chain proves internal consistency only. Any process that can write the file can alter entry N and recompute hashes N+1…end in milliseconds. Your existing chain detects casual editing and corruption; it does not resist an adversary with write access.

**Three layers close the gap.** (1) **HMAC-signed entries** with a key the pipeline host does not hold — keep the key on the machine (or USB drive) you use for verification sessions only. A compromised extraction box can then corrupt the future but cannot forge signed history. (2) **Content addressing**: each decision embeds the sha256 of the exact evidence text approved, so a past approval can't be silently re-pointed at different evidence. (3) **External anchoring**: after each session, write `log.head()` (16 hex chars) somewhere the pipeline can't — a notebook, an email to yourself, a git repo elsewhere. The test suite demonstrates why this matters: a *truncated* log verifies as internally consistent and is caught **only** by the anchor. Anchoring converts "rewrite the file" into "rewrite the file and the outside world."

**Data model** (`VerificationEntry`): seq, prev_hash, timestamp, reviewer_id, action (`approve|reject|modify|flag_for_recheck`), article_id, claim_ref, evidence_sha256, changes (old/new hashes for modifications), required human-typed rationale, entry_hash, HMAC signature. The standalone verifier detects modification, forgery, deletion (seq gaps), insertion/reorder (chain breaks), and — with an anchor — truncation. Run it on a machine the pipeline can't write to; a verifier the adversary can edit verifies nothing.

**Escalation path if this ever becomes multi-party or contested:** per-reviewer asymmetric keys (Ed25519) instead of shared HMAC, so entries are attributable and non-repudiable. Overkill for one researcher; one import away if needed.

---

## 5. OCR Fallback (`ocr_fallback.py`)

Detection is **per page** (<100 chars → scanned), because policy PDFs are routinely mixed: typed body, scanned appendix. Fallback renders at 300 DPI → pytesseract with word confidences; mean confidence below 60 flags the page. Every OCR'd page is logged to `ocr_pages.log.jsonl` for audit, and evidence quotes originating from OCR'd pages should carry `ocr: true` downstream — a reviewer checking a quote against imperfect text deserves to know.

The cleanup layer is regex-only by default (ligatures, digit-context l/1/O/0 confusions, de-hyphenation, gibberish-line removal). The LLM cleanup pass exists but ships **off**: a model "fixing" OCR can silently rewrite evidence, which is a worse failure than the noise it fixes. If you enable it for high-value pages, its use must be logged per page and its output never quoted without human comparison to the page image. Note the interaction with §8's verbatim-quote check: quotes from OCR pages are checked against *OCR text*, not ground truth — the check catches model hallucination, not scanner error; only the human review closes that last gap.

**Testing.** Regex layer covered offline. Integration: build a tiny fixture set — one born-digital PDF, one printed-and-scanned, one mixed — and assert per-page method selection and audit-log contents.

---

## 6. Concurrency & Throughput (`rate_controller.py`)

**Audit of the current pattern.** Fixed-concurrency `asyncio.gather` with naive retries has a known death spiral: load rises → latency rises → timeouts fire → retries multiply offered load (thundering herd) → vLLM queue deepens → P99 goes vertical. Each worker discovers the cliff independently and re-offers its load.

**Redesign: AIMD, the TCP congestion algorithm.** Additive increase (+1 per healthy 10 s window), multiplicative decrease (×0.6) on any of: observed P99 > 5 s, vLLM `num_requests_waiting` > 8, or `gpu_cache_usage_perc` > 0.90. Metrics scraping is best-effort — if `/metrics` is unreachable, latency alone steers. A shared `penalize()` on timeout backs *everyone* off at once. The **retry budget** (retries ≤ 10% of the last minute's requests) is the herd-killer: beyond budget, retries queue rather than stampede. Tenacity supplies jittered exponential backoff for *when* to retry; the budget gates *whether* the retry is admitted.

**Sizing math for max_concurrent start value.** Scout-17B FP8 on one H100 via vLLM sustains very roughly 2,500–5,000 output tok/s under continuous batching (verify against your own pilot!). At ~350 output tokens per request, that's ~7–14 requests/s completing. With P99 target 5 s, Little's law says concurrency ≈ throughput × latency ≈ 7×2 to 14×3 — a healthy operating point in the 15–40 range. **Start at 16**; the controller finds the true ceiling within minutes. The point of the controller is precisely that this paragraph's estimates don't need to be right.

**Testing.** The suite simulates growth on healthy latencies, multiplicative decrease on congested metrics, and exact retry-budget enforcement (5 of 6 admitted at 10% of 50). Add a soak test against your real endpoint: 30 minutes at pilot load, assert P99 stays under target and the limit converges rather than oscillating.

---

## 7. Cost & Resilience (`checkpoint.py`)

**Full-run model — 18,000 articles.** Assumptions (recalibrate on pilot): mean article ~900 words ≈ 1,200 tokens → ~2.5 chunks of 600 tokens; system prompt ~850 tokens (prefix-cached by vLLM, so marginal); ~350 output tokens/chunk.

- Requests: 18,000 × 2.5 = **45,000** + 3% timeout retries + 1% repair retries ≈ **46,800**
- Output tokens: ~16.4 M; at 2,500–5,000 tok/s sustained → **0.9–1.8 GPU-hours** of pure generation. With scheduling overhead, OCR-delayed articles (0.5% × ~30 s), warmup, and one partial re-run, budget **4–8 H100-hours** wall-clock.
- **Compute cost: $8–32** at $2–4/hr. Even ±3× wrong, compute is noise.
- **Human verification: 20% × 18,000 × 2 min = 1,200 hours? No — 120 hours.** 3,600 articles × 2 min = 7,200 min = **120 hours ≈ 15 working days.** That is 30–60× the compute cost at any wage, and it is the number that decides whether this project ships.

**The design consequence:** every optimization hour belongs to the *reviewer experience*, not the GPU bill. Three highest-leverage moves: (a) present evidence quote + surrounding context + one-keystroke approve/reject/modify (2 min/article is achievable only with zero navigation); (b) order the queue by extraction confidence ascending so fatigue lands on easy cases; (c) route `E_*` error codes into the same queue with the error pre-explained. A 25% reviewer-speed gain saves 30 hours — a thousand times the value of any token optimization.

**Checkpointing.** Per-*chunk* state in SQLite (WAL mode): a crash loses at most one LLM call, resume is `pending_chunks()` — the absence of a feature rather than a feature. Identity is content sha256, so re-queuing the corpus is a no-op and a changed source is visibly new. Repairs and token counts ride along per chunk, which makes §2's repair rate and §7's cost model *measured* rather than assumed. For durability, sync the `.db` to S3 between runs (SQLite copies safely with no active writer).

---

## 8. Extraction Prompt & Bias (`extraction_prompt.py`)

The prompt (~830 tokens, leaving ~6.5k for chunk + output in an 8k window) enforces: exact tag strings only; **verbatim-substring evidence quotes** (machine-checkable — `verify_quotes()` turns hallucinated evidence into automatic rejection); empty-tags-is-a-valid-answer (the second example exists specifically because small models over-tag without a restraint demonstration); behaviorally defined confidence ("would a careful reader agree?" — undefined confidence collapses to 0.9 for everything); and no keys beyond the four. **The 12 tags shipped are structural placeholders — you never told me your framework, and inventing it for you would be fabrication. Replace names and definitions before any run.**

**Bias mitigation — measured, not assumed.** A model can systematically tag identical conduct differently depending on the actor or outlet. You cannot prompt this away; you can only measure it:

1. **Calibration set:** ~240 chunks (20/tag), stratified by outlet across an external media-lean rating (e.g., left/center/right per an established chart), hand-labeled by you *before* seeing model output. This is ground truth; version it and never train the prompt on it.
2. **Baseline metrics:** per-tag precision/recall against your labels, and per-tag assignment rates **conditioned on outlet lean**. The bias signal is an interaction: e.g., INDUSTRY_CONDUCT recall of 0.9 on lean-left sources but 0.6 on lean-right coverage of the same conduct. Test the biggest gaps with counterfactual pairs — same paragraph, actor/outlet names swapped — where any tag-set change is bias by construction, not topic mix.
3. **Ongoing monitoring:** per-run tag-rate-by-outlet-lean distributions from the checkpoint DB; a chi-square (or eyeballed proportion) drift alarm against the pilot baseline. Re-run the calibration set after any prompt or model change — it doubles as your canary set.
4. **Disclosure:** the calibration results — per-tag agreement rates and any residual lean-conditioned gaps — belong in the report's methods section. For a policy advocacy report especially, "we measured our extractor's bias and here are the numbers" is worth more credibility than any claim of neutrality, and it is the register of honesty this whole pipeline was built to earn.

---

## Priority Order

1. **Neo4j parameterization** (§3) — active correctness/safety bug; hours of work.
2. **Checkpointing** (§7) — everything else generates state worth not losing.
3. **JSON repair + verbatim-quote check** (§2, §8) — directly reduces the human-review bill.
4. **Rate controller** (§6) — before the first full-scale run, not after the first meltdown.
5. **Signed verification log** (§4) — before the first real human verification session, so no unsigned history ever needs migrating.
6. **Cleaning/chunking, OCR, prompt calibration** (§1, §5, §8) — quality layers; land them during the pilot.

Run the 20-article pilot after step 4; it recalibrates every number in this document.
