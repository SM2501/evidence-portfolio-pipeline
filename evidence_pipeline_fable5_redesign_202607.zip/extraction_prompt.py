"""
extraction_prompt.py — 12-tag extraction prompt for Llama 4 Scout.
==================================================================
Section 8 of the pipeline redesign.

IMPORTANT: You never gave me your actual 12 tags, so TAGS below is a
STRUCTURAL PLACEHOLDER shaped like a plausible framework for this corpus.
Replace the names and one-line definitions with your real framework before
any production run — inventing your taxonomy for you would be exactly the
kind of fabrication this pipeline exists to prevent.

Prompt design choices (rationale in the audit document):
  * Definitions are one line each: Scout at 17B follows short, positive
    definitions better than long negative ones, and the whole prompt must
    leave room for a ~600-token chunk inside 8k context. This prompt is
    ~1.4k tokens with examples.
  * Two-shot, not zero-shot: one multi-tag example, one near-miss example
    that assigns FEW tags — without a restraint example, small models
    over-tag.
  * evidence_quotes must be VERBATIM substrings. This is machine-checkable
    (assert quote in chunk_text), turning hallucinated evidence into an
    automatic rejection instead of a human-review burden.
  * confidence is defined behaviorally ("would a careful reader agree?"),
    because undefined confidence scores collapse to 0.9 for everything.
"""

from __future__ import annotations

from typing import Dict, List

# ------------------------------------------------------------------
# REPLACE WITH YOUR REAL 12-TAG FRAMEWORK (name -> one-line definition)
# ------------------------------------------------------------------
TAGS: Dict[str, str] = {
    "SUPPLY_CONTAMINATION":   "Adulterants or potency variability in the drug supply.",
    "POLICY_INTERVENTION":    "A specific law, rule, program, or enforcement action.",
    "HEALTH_OUTCOME":         "Morbidity, mortality, or clinical outcomes with data.",
    "DATA_QUALITY_ISSUE":     "Limitations, revisions, or gaps in the cited data.",
    "CRIMINALIZATION":        "Criminal-legal system involvement or its effects.",
    "HARM_REDUCTION":         "Services or practices reducing drug-related harm.",
    "INDUSTRY_CONDUCT":       "Corporate behavior: marketing, lobbying, litigation.",
    "MEDIA_FRAMING":          "How coverage frames actors, causes, or blame.",
    "LIVED_EXPERIENCE":       "First-person accounts of people who use drugs.",
    "REGULATORY_ACTION":      "Agency decisions: approvals, bans, warnings, audits.",
    "RESEARCH_FINDING":       "A study result with methodology or citation.",
    "ECONOMIC_FACTOR":        "Costs, funding, markets, or economic incentives.",
}

_EXAMPLE_1_TEXT = (
    "State health officials reported Tuesday that overdose deaths fell 8% in "
    "counties operating syringe-service programs, though the report cautions "
    "that provisional death data are typically revised upward. The Sentinel's "
    "front page nonetheless declared the crisis 'finally beaten.'"
)
_EXAMPLE_1_JSON = (
    '{"tags": ["HEALTH_OUTCOME", "HARM_REDUCTION", "DATA_QUALITY_ISSUE", '
    '"MEDIA_FRAMING"], '
    '"evidence_quotes": ["overdose deaths fell 8% in counties operating '
    'syringe-service programs", "provisional death data are typically revised '
    'upward", "declared the crisis \'finally beaten\'"], '
    '"rationale": "Outcome data tied to a harm-reduction service, with an '
    'explicit data caveat, contrasted against triumphalist framing.", '
    '"confidence": 0.86}'
)

_EXAMPLE_2_TEXT = (
    "The city council meeting ran long on Tuesday, with members debating "
    "parking-permit fees for most of the evening before adjourning."
)
_EXAMPLE_2_JSON = (
    '{"tags": [], "evidence_quotes": [], '
    '"rationale": "No content relevant to the framework; municipal parking '
    'debate only.", "confidence": 0.95}'
)


def build_system_prompt(tags: Dict[str, str] | None = None) -> str:
    tags = tags or TAGS
    assert len(tags) == 12, "framework must contain exactly 12 tags"
    tag_block = "\n".join(f"- {name}: {definition}" for name, definition in tags.items())
    return f"""You are an evidence extractor for a human-verified research project. You classify ONE text chunk against a fixed 12-tag framework and return ONE JSON object. A human reviewer checks your output against the source; your job is recall with honest confidence, not persuasion.

THE 12 TAGS (use these exact strings; no others exist):
{tag_block}

OUTPUT FORMAT — exactly one JSON object, nothing before or after it:
{{
  "tags": [],              // zero or more of the 12 exact tag strings
  "evidence_quotes": [],   // VERBATIM substrings copied from the chunk, one per distinct piece of evidence
  "rationale": "",         // one or two sentences connecting quotes to tags
  "confidence": 0.0        // 0.0-1.0: the probability a careful human reader of this chunk would agree with your tag set
}}

RULES:
1. evidence_quotes must be exact, character-for-character substrings of the chunk. Never paraphrase inside quotes. If you cannot quote it, you cannot tag it.
2. Assign a tag ONLY when the chunk itself contains evidence for it. An empty tags array is a correct and common answer.
3. Do not use outside knowledge about the events; classify only what this chunk states.
4. No explanatory text, markdown fences, apologies, or keys other than the four above.
5. Calibrate confidence honestly: 0.9+ means unambiguous; 0.5 means a careful reader might reasonably disagree; below 0.4, prefer dropping the tag and noting the ambiguity in rationale.

EXAMPLE A
Chunk: "{_EXAMPLE_1_TEXT}"
Output: {_EXAMPLE_1_JSON}

EXAMPLE B
Chunk: "{_EXAMPLE_2_TEXT}"
Output: {_EXAMPLE_2_JSON}"""


def build_user_prompt(chunk_text: str) -> str:
    return f"Classify this chunk:\n\n{chunk_text}"


def verify_quotes(result: dict, chunk_text: str) -> List[str]:
    """Machine check: every evidence quote must be a verbatim substring.
    Returns the list of hallucinated quotes (empty = clean)."""
    return [q for q in result.get("evidence_quotes", []) if q not in chunk_text]
