"""Test suite for the redesign modules (everything testable offline)."""
import asyncio
import json
import os
from pathlib import Path

os.chdir(Path(__file__).parent)

# ============ Section 1: text_cleaning ============
from text_cleaning import clean_text, chunk_text, split_sentences, detect_script, count_tokens

dirty = """<script>var x = 1; window.track();</script>
<style>.nav{color:red;}</style>
Subscribe to our newsletter today!
Accept all cookies
HOME
HOME
HOME
HOME
The mayor said the program reduced deaths by 8%. Dr. Smith of the U.S. CDC disagreed, citing revised data. A third study found no effect.

© 2026 Example Media. All rights reserved."""
cleaned = clean_text(dirty)
assert "var x" not in cleaned and "Subscribe" not in cleaned and "cookies" not in cleaned
assert "©" not in cleaned and cleaned.count("HOME") <= 2
assert "reduced deaths by 8%" in cleaned
print("1a. pre-cleaning OK")

sents = split_sentences("Dr. Smith of the U.S. CDC disagreed. Mr. Jones concurred. It rose 5%.")
assert len(sents) == 3, sents
print("1b. abbreviation-safe sentence split OK:", len(sents), "sentences")

long_text = " ".join(f"Sentence number {i} contains several words about policy and outcomes." for i in range(200))
chunks = chunk_text(long_text, max_tokens=150, overlap_sentences=2, pre_clean=False)
assert all(c.token_count <= 150 for c in chunks)
# overlap property: consecutive chunks share sentences
joined = [set(c.text.split(". ")) for c in chunks]
assert all(len(joined[i] & joined[i+1]) >= 1 for i in range(len(joined)-1))
# no mid-word cuts
assert all(not c.text.startswith(("umber", "entence")) for c in chunks)
# pathological sentence
mono = "word " * 800
mono_chunks = chunk_text(mono, max_tokens=100, pre_clean=False)
assert all(c.token_count <= 110 for c in mono_chunks)
assert all(not c.text.startswith("ord") for c in mono_chunks)  # never mid-word
print(f"1c. token-aware chunking OK: {len(chunks)} chunks, overlap preserved, no mid-word cuts")

rep = detect_script("قالت الوزارة إن الوفيات انخفضت بنسبة كبيرة هذا العام في جميع المناطق")
assert rep.is_rtl and "rtl" in rep.recommendation
rep_en = detect_script("The ministry said deaths fell sharply this year across all regions of the country.")
assert "process" in rep_en.recommendation
print("1d. script/RTL detection OK")

# ============ Section 2: json_repair ============
from json_repair import extract_and_repair, enforce_schema, prompt_for_attempt, E_EMPTY_TAGS

cases = {
    "fenced": '```json\n{"tags": ["A"], "confidence": 0.8}\n```',
    "commentary": 'Sure! Here is the JSON you asked for:\n{"tags": ["A"], "confidence": 0.8}\nHope that helps!',
    "trailing_comma": '{"tags": ["A", "B",], "confidence": 0.8,}',
    "unquoted_keys": '{tags: ["A"], confidence: 0.8}',
    "truncated": '{"tags": ["A"], "evidence_quotes": ["the deaths fell', 
    "dup_keys": '{"tags": ["A"], "tags": ["B"], "confidence": 0.7}',
    "single_quotes": "{'tags': ['A'], 'confidence': 0.9}",
    "extra_key": '{"tags": ["A"], "confidence": 0.8, "explanation": "blah"}',
}
for name, raw in cases.items():
    r = extract_and_repair(raw)
    assert r.ok, f"{name} failed: {r.errors}"
assert extract_and_repair(cases["dup_keys"]).data["tags"] == ["A"]  # first wins
assert not extract_and_repair("I cannot classify this chunk.").ok
print(f"2a. JSON repair OK across {len(cases)} malformation classes")

allowed = ["A", "B", "C"]
good = enforce_schema({"tags": "A; B", "evidence_quotes": "a quote",
                       "rationale": "r", "confidence": 85,
                       "explanation": "dropped"}, allowed)
assert good.ok and good.data["tags"] == ["A", "B"] and good.data["confidence"] == 0.85
assert "explanation" not in good.data
bad = enforce_schema({"tags": ["ZZZ"], "evidence_quotes": [], "rationale": "r",
                      "confidence": 0.5}, allowed)
assert not any(e.startswith("E_BAD_TYPE") for e in bad.errors) and E_EMPTY_TAGS in bad.errors
missing = enforce_schema({"tags": ["A"]}, allowed)
assert not missing.ok and any("E_MISSING_FIELD" in e for e in missing.errors)
p0, p2 = prompt_for_attempt("base", 0), prompt_for_attempt("base", 2)
assert p0 == "base" and "STRICT MODE" in p2
print("2b. schema enforcement + retry prompt mutation OK")

# ============ Section 3: neo4j_loader (offline parts) ============
from neo4j_loader import dynamic_batches, _check_label, _check_rel, LabelNotAllowed

small = [{"id": f"n{i}", "props": {"d": "x"}} for i in range(500)]
big = [{"id": f"n{i}", "props": {"d": "y" * 50_000}} for i in range(500)]
small_batches = list(dynamic_batches(small))
big_batches = list(dynamic_batches(big))
assert len(big_batches) > len(small_batches), "byte-based sizing not engaging"
assert sum(len(b) for b in big_batches) == 500
assert _check_rel("DROP DATABASE") == "UNKNOWN"  # injection degraded, not executed
try:
    _check_label("Evil`) DETACH DELETE (n")
    raise SystemExit("FAIL: label injection allowed")
except LabelNotAllowed:
    pass
print(f"3. loader OK: {len(small_batches)} small vs {len(big_batches)} big batches; injection blocked")

# ============ Section 4: audit_verifier ============
from audit_verifier import SignedVerificationLog, verify_log

for f in ("v.log.jsonl", "k.key"):
    Path(f).unlink(missing_ok=True)
Path("k.key").write_bytes(b"a" * 64)
vlog = SignedVerificationLog("v.log.jsonl", "k.key")
for i in range(5):
    vlog.append(reviewer_id="AB", action="approve", article_id=f"art{i}",
                claim_ref="claims[0]", evidence_text=f"evidence {i}",
                rationale=f"checked source {i}")
head = vlog.head()
assert verify_log("v.log.jsonl", "k.key", head).ok

lines = Path("v.log.jsonl").read_text().splitlines()
# tamper: modify a rationale
e = json.loads(lines[2]); e["rationale"] = "rewritten history"
Path("t1.jsonl").write_text("\n".join(lines[:2] + [json.dumps(e)] + lines[3:]) + "\n")
assert not verify_log("t1.jsonl", "k.key").ok
# tamper: delete an entry
Path("t2.jsonl").write_text("\n".join(lines[:2] + lines[3:]) + "\n")
assert not verify_log("t2.jsonl", "k.key").ok
# tamper: truncate (detected only via anchor)
Path("t3.jsonl").write_text("\n".join(lines[:3]) + "\n")
assert verify_log("t3.jsonl", "k.key").ok            # internally consistent!
assert not verify_log("t3.jsonl", "k.key", head).ok  # anchor catches it
# forged with wrong key
Path("k2.key").write_bytes(b"b" * 64)
forged = SignedVerificationLog("t4.jsonl", "k2.key")
forged.append(reviewer_id="XX", action="approve", article_id="a", claim_ref="c",
              evidence_text="e", rationale="fake")
assert not verify_log("t4.jsonl", "k.key").ok
print("4. signed log OK: modify/delete/truncate/forge all detected (truncation via anchor)")

# ============ Section 5: OCR cleanup (regex layer) ============
from ocr_fallback import clean_ocr_text

ocr = "The ﬁnal report showed 4l2 deaths in 2O25.\nphar-\nmacies dispensed doses.\n@@@@@@@@\n"
c = clean_ocr_text(ocr)
assert "final" in c and "412" in c and "2025" in c and "pharmacies" in c
assert "@@@" not in c
print("5. OCR cleanup OK:", repr(c[:60]))

# ============ Section 6: rate_controller ============
from rate_controller import AdaptiveRateController, ControllerConfig, parse_vllm_metrics

async def controller_sim():
    cfg = ControllerConfig(initial_concurrent=16, window_seconds=0.01,
                           target_p99_seconds=5.0)
    c = AdaptiveRateController(cfg)
    # healthy latencies -> limit grows
    for _ in range(50):
        c.record_latency(0.8)
    async with c.slot():
        pass
    await asyncio.sleep(0.02)
    async with c.slot():
        pass
    grew = c.limit
    # congestion signal from metrics -> multiplicative decrease
    c.observe_metrics(parse_vllm_metrics(
        "vllm:num_requests_waiting 25\nvllm:gpu_cache_usage_perc 0.95\n"))
    shrunk = c.limit
    assert shrunk < grew and shrunk >= cfg.min_concurrent
    # retry budget: 50 recent requests × 10% = 5 slots; the 6th must be blocked
    got_retry = 0
    async def try_retry():
        nonlocal got_retry
        try:
            await asyncio.wait_for(c._acquire(True), timeout=0.3)
            got_retry += 1
        except asyncio.TimeoutError:
            pass
    await asyncio.gather(*[try_retry() for _ in range(6)])
    assert got_retry == 5, f"retry budget wrong: admitted {got_retry}/6, expected 5"
    return grew, shrunk, got_retry

grew, shrunk, got_retry = asyncio.run(controller_sim())
print(f"6. rate controller OK: AIMD {16}->{grew}->{shrunk}; retry budget admitted {got_retry}/6")

# ============ Section 7: checkpoint ============
from checkpoint import CheckpointStore

Path("state.db").unlink(missing_ok=True)
store = CheckpointStore("state.db")
assert store.enqueue("hash1", "https://x/1") and not store.enqueue("hash1")  # dedupe
store.set_chunk_count("hash1", 4)
store.record_chunk("hash1", 0, payload={"tags": ["A"]}, tokens_in=500, tokens_out=100)
store.record_chunk("hash1", 2, payload={"tags": []}, repairs=["removed_trailing_commas"])
assert store.pending_chunks("hash1") == [1, 3]  # exact resume
store.record_chunk("hash1", 1, payload={"tags": ["B"]})
store.record_chunk("hash1", 3, payload=None, error="timeout")
assert store.pending_chunks("hash1") == [3]     # failed chunk stays pending
store.finish_article("hash1")
s = store.summary()
assert s["tokens_in"] == 500 and s["chunks_needing_repair"] == 1
assert "hash1" not in store.claim_work()
print("7. checkpointing OK: dedupe, exact per-chunk resume, failed-chunk retry, summary")

# ============ Section 8: extraction prompt ============
from extraction_prompt import build_system_prompt, verify_quotes, TAGS
from text_cleaning import count_tokens as ct

sp = build_system_prompt()
assert ct(sp) < 2000, f"system prompt too large: {ct(sp)} tokens"
assert all(t in sp for t in TAGS)
halluc = verify_quotes({"evidence_quotes": ["real text here", "invented quote"]},
                       "the chunk contains real text here only")
assert halluc == ["invented quote"]
print(f"8. prompt OK: ~{ct(sp)} tokens (fits 8k with a 600-token chunk); "
      "hallucinated-quote check works")

print("\nALL REDESIGN CHECKS PASSED")
