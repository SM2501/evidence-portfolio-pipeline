# Evidence Portfolio Pipeline

A computational-journalism ETL pipeline that classifies pain-care and
drug-policy news coverage against a fixed 12-tag framework, builds a
provisional evidence graph, and enforces cryptographically signed
human verification before anything is treated as fact.

**The one rule:** everything the model produces is `llm_provisional`.
Evidence becomes citable only through the signed human review in
`src/verify.py`. There is no other door.

## Architecture

```
 corpus/*.txt ──► enqueue (clean, sha256 identity, dedupe, archive, chunk-count)
                      │            [src/text_cleaning.py, src/checkpoint.py]
                      ▼
              ┌─ producer ─────────────── pending chunks only (exact resume)
              │        asyncio.Queue (bounded → backpressure)
              │  ┌──────────┬──────────┬──────────┐
              └─►│ worker 1 │ worker 2 │ worker N │   [pipeline_orchestrator.py]
                 └────┬─────┴────┬─────┴────┬─────┘
                      ▼          ▼          ▼
              AdaptiveRateController (ONE shared instance: AIMD on P99 +
              vLLM /metrics; 10% retry budget)      [rate_controller.py]
                      │
                      ▼
              LLM (RunPod vLLM ── or MockLLMClient)      [llm_client.py]
                      │ raw text
                      ▼
              extract_and_repair ─► enforce_schema ─► enforce_framework
              (fences, truncation,   (types, tag       (SCOPE pair rule)
               dup keys — recorded)   whitelist)      [json_repair.py,
                      │                                extraction_prompt.py]
                      ▼
              verify_quotes (verbatim-substring check)
                      │                    │ discrepancy
                      ▼                    ▼
              checkpoint (per CHUNK,   triage_queue.jsonl ─► src/verify.py
              SQLite WAL)              (human review; HMAC-signed,
                      │                 hash-chained decisions)
                      ▼                              [audit_verifier.py]
              graph_out/<article>.json  ─►  Neo4j via parameterized
              (whitelisted labels,           UNWIND batches
               llm_provisional)             [neo4j_loader.py]
```

PDF sources: `src/ocr_fallback.py` (per-page scanned-page detection at
<100 chars, 300-DPI pytesseract fallback, per-page audit log) feeds the
same enqueue path.

## Installation

```bash
python3.10+ required
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# optional extras: pip install tiktoken langdetect json-repair neo4j pymupdf pytesseract pillow
cp .env.example .env    # fill in RunPod endpoint + key
python -m src.test_redesign          # 18 checks, no network needed
```

## Configuration

Everything lives in `src/config.py`: the 12-tag vocabulary (11 content
tags + the SCOPE_LOCAL/SCOPE_NATIONAL pair), model endpoint (env:
`RUNPOD_BASE_URL`, `RUNPOD_API_KEY`, `RUNPOD_MODEL`), chunking knobs,
worker count, and all paths (override with `PIPELINE_DATA_DIR`;
signing key defaults to `~/.pipeline/audit_key`, override with
`PIPELINE_AUDIT_KEY`).

## Running

```bash
# Extraction (resumable; re-running is always safe)
python -m src.pipeline_orchestrator corpus/ --workers 8
python -m src.pipeline_orchestrator corpus/ --mock       # no network

# Human verification (the only path from provisional to citable)
python -m src.verify keygen
python -m src.verify queue
python -m src.verify review
python -m src.verify head      # anchor this hash OUTSIDE the pipeline
python -m src.verify check --anchor <hex>

# Neo4j load (after extraction; parameterized, whitelisted)
python -c "from neo4j import GraphDatabase; from src.neo4j_loader import *; \
import json, pathlib; d=GraphDatabase.driver('bolt://localhost:7687', \
auth=('neo4j','password')); setup_constraints(d); \
[ (load_nodes(d, g['nodes']), load_edges(d, g['edges'])) \
  for g in (json.loads(p.read_text()) for p in pathlib.Path('data/graph_out').glob('*.json')) ]"
```

## Concurrency Math

Llama 4 Scout (17B active, FP8) on one H100 under vLLM continuous
batching sustains roughly 2,500–5,000 output tok/s (verify on your own
pilot). At ~350 output tokens per classification, that completes ~7–14
requests/s. Little's law: concurrency ≈ throughput × latency; for a 5 s
P99 target that puts the healthy operating point around 15–40 in-flight
requests. The controller **starts at 16** and finds the true ceiling via
AIMD (+1/window on health, ×0.6 on congestion), steered by observed P99
and vLLM's `num_requests_waiting` / `gpu_cache_usage_perc`. Retries are
capped at 10% of the last minute's offered load, which converts a retry
herd into a queue. The point of the controller is that this paragraph's
estimates don't need to be right.

Cost reality check (18k articles, ~2.5 chunks each): pure compute is a
few H100-hours — **$8–32**. Human verification at 20% × 2 min/article is
**~120 hours**. The reviewer experience, not the GPU bill, is the
binding constraint; `verify.py` is designed around that.

## Ethical & Bias Disclosure Guidelines

This pipeline classifies coverage of taper harms, veteran suicide,
patient abandonment, and drug policy — topics where framing itself is
contested. The following are commitments, not decoration:

1. **Nothing provisional is ever cited.** Every extracted item carries
   `epistemic_status: llm_provisional` until a named human signs an
   approval with a typed rationale. Downstream quotability gates must
   WHITELIST trusted statuses, never blacklist provisional ones.
2. **Measure the extractor's bias; don't assert its neutrality.** Before
   the full run, hand-label a calibration set (~20 chunks per tag,
   stratified by outlet lean using an external media-bias rating).
   Report per-tag precision/recall AND per-tag assignment rates
   conditioned on outlet lean. Probe the largest gaps with
   counterfactual pairs (same paragraph, actor names swapped). Publish
   the numbers — including the unflattering ones — in the report's
   methods section, with the measured extraction error rate from
   ongoing triage sampling.
3. **Verbatim evidence only.** Quotes that fail the character-for-
   character source check are quarantined and triaged, never published.
   Quotes from OCR'd pages carry an `ocr` flag; reviewers compare
   against the page image, not the OCR text.
4. **Personal accounts are people.** PERSONAL_ACCOUNT evidence
   describing suicidality or medical harm is handled under the project's
   source-protection norms: no republication of identifying details
   beyond what the original outlet published, and human review of every
   such item before any use.
5. **The audit trail must survive its own author.** Decisions are
   HMAC-signed with a key kept apart from the extraction host, and the
   session head hash is anchored outside the pipeline after every review
   session. `python -m src.verify check --anchor <hex>` detects
   modification, forgery, deletion, insertion, and truncation.
6. **Disclose the machinery.** The published report states: corpus size
   and selection, the model and prompt version, repair and triage rates,
   the human verification rate, and this pipeline's role — machine
   nominates, human verifies.

## Repository Layout

```
src/
├── config.py               # 12-tag vocabulary, endpoints, paths, knobs
├── text_cleaning.py        # pre-clean, token-aware chunking, RTL routing
├── json_repair.py          # extraction/repair, schema, retry mutation
├── extraction_prompt.py    # system prompt, SCOPE rule, verbatim-quote check
├── llm_client.py           # RunPodClient + MockLLMClient
├── rate_controller.py      # shared AIMD controller + retry budget
├── checkpoint.py           # SQLite WAL, per-chunk state, exact resume
├── pipeline_orchestrator.py# async producer-consumer loop
├── neo4j_loader.py         # parameterized UNWIND, label whitelist
├── ocr_fallback.py         # per-page scanned-PDF OCR with audit log
├── audit_verifier.py       # signed hash-chained log + tamper verifier
├── verify.py               # human review CLI (the only door)
└── test_redesign.py        # 18 checks incl. mock end-to-end run
```
