"""
src/extraction_prompt.py — 12-tag extraction prompt + framework validation.
===========================================================================
The system prompt enforces: exact tag strings, verbatim evidence quotes
(machine-checkable via verify_quotes), the SCOPE pair rule, restraint
(empty tags is a valid answer), and behaviorally defined confidence.
~1k tokens with examples, leaving room for a 600-token chunk in 8k context.
"""

from __future__ import annotations

from typing import Dict, List

from src.config import ALL_TAGS, CONTENT_TAGS, SCOPE_TAGS, E_SCOPE

_EXAMPLE_1_TEXT = (
    "After the clinic cut her dose by half in a single month, Ms. Alvarez said "
    "she began experiencing withdrawal and uncontrolled pain, and twice "
    "considered ending her life. Her pharmacist, citing the state guideline, "
    "declined to fill the remaining prescription. The Tribune-Ledger, which "
    "covers three counties, reviewed her medical records."
)
_EXAMPLE_1_JSON = (
    '{"tags": ["TAPER_HARM", "PERSONAL_ACCOUNT", "PATIENT_ABANDONMENT", '
    '"SCOPE_LOCAL"], '
    '"evidence_quotes": ["cut her dose by half in a single month", '
    '"began experiencing withdrawal and uncontrolled pain, and twice '
    'considered ending her life", '
    '"citing the state guideline, declined to fill the remaining prescription"], '
    '"rationale": "First-person taper narrative with documented harm and a '
    'guideline-justified refusal of care; three-county regional outlet.", '
    '"confidence": 0.88}'
)

_EXAMPLE_2_TEXT = (
    "The city council meeting ran long on Tuesday, with members debating "
    "parking-permit fees for most of the evening before adjourning."
)
_EXAMPLE_2_JSON = (
    '{"tags": [], "evidence_quotes": [], '
    '"rationale": "No content relevant to the framework; municipal parking '
    'debate only.", "confidence": 0.95}'
)


def build_system_prompt(tags: Dict[str, str] | None = None) -> str:
    content = {k: v for k, v in (tags or ALL_TAGS).items() if k in CONTENT_TAGS} \
        if tags else CONTENT_TAGS
    tag_block = "\n".join(f"- {name}: {definition}"
                          for name, definition in content.items())
    scope_block = "\n".join(f"- {name}: {definition}"
                            for name, definition in SCOPE_TAGS.items())
    return f"""You are an evidence extractor for a human-verified research project on pain-care and drug-policy coverage. You classify ONE text chunk against a fixed 12-tag framework and return ONE JSON object. A human reviewer checks your output against the source; your job is recall with honest confidence, not persuasion.

CONTENT TAGS (use these exact strings; no others exist):
{tag_block}

SCOPE TAG (tag 12 — a required pair; assign EXACTLY ONE whenever any content tag applies):
{scope_block}

OUTPUT FORMAT — exactly one JSON object, nothing before or after it:
{{
  "tags": [],              // zero or more content tags; plus exactly one SCOPE_* if any content tag applies
  "evidence_quotes": [],   // VERBATIM substrings copied from the chunk, one per distinct piece of evidence
  "rationale": "",         // one or two sentences connecting quotes to tags
  "confidence": 0.0        // 0.0-1.0: the probability a careful human reader of this chunk would agree with your tag set
}}

RULES:
1. evidence_quotes must be exact, character-for-character substrings of the chunk. Never paraphrase inside quotes. If you cannot quote it, you cannot tag it.
2. Assign a tag ONLY when the chunk itself contains evidence for it. An empty tags array is a correct and common answer.
3. If you assign any content tag, you MUST also assign exactly one of SCOPE_LOCAL or SCOPE_NATIONAL. If tags is empty, assign no scope tag.
4. Do not use outside knowledge about the events; classify only what this chunk states.
5. No explanatory text, markdown fences, apologies, or keys other than the four above.
6. Calibrate confidence honestly: 0.9+ means unambiguous; 0.5 means a careful reader might reasonably disagree; below 0.4, prefer dropping the tag and noting the ambiguity in rationale.

EXAMPLE A
Chunk: "{_EXAMPLE_1_TEXT}"
Output: {_EXAMPLE_1_JSON}

EXAMPLE B
Chunk: "{_EXAMPLE_2_TEXT}"
Output: {_EXAMPLE_2_JSON}"""


def build_user_prompt(chunk_text: str) -> str:
    return f"Classify this chunk:\n\n{chunk_text}"


def enforce_framework(clean: dict) -> List[str]:
    """Framework rules beyond generic schema: the SCOPE pair.

    Any classification carrying at least one content tag must carry exactly
    one scope tag; an empty classification carries none. Violations return
    [E_SCOPE:*] codes for triage routing — they are review signals, not
    hard failures, because the content tags may still be right.
    """
    tags = set(clean.get("tags", []))
    content = tags & set(CONTENT_TAGS)
    scope = tags & set(SCOPE_TAGS)
    errors: List[str] = []
    if content and len(scope) != 1:
        errors.append(f"{E_SCOPE}:expected_exactly_one_scope_got_{len(scope)}")
    if not content and scope:
        errors.append(f"{E_SCOPE}:scope_without_content_tags")
    return errors


def verify_quotes(result: dict, chunk_text: str) -> List[str]:
    """Machine check: every evidence quote must be a verbatim substring.
    Returns the list of hallucinated quotes (empty = clean)."""
    return [q for q in result.get("evidence_quotes", []) if q not in chunk_text]
