"""
text_cleaning.py — Pre-clean, token-aware chunking, language/script detection.
==============================================================================
Section 1 of the pipeline redesign.

Design: clean FIRST, then chunk on sentence boundaries with token budgets and
sentence overlap, so no evidence quote is ever cut mid-sentence and evidence
spanning a boundary appears intact in at least one chunk.

Token counting uses tiktoken when its encoding is available and degrades to a
calibrated chars/4 heuristic when offline — chunk sizes drift ~10% under the
fallback, which the max_tokens safety margin absorbs.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import List, Optional

# ---------------------------------------------------------------------------
# Token counting (graceful degradation)
# ---------------------------------------------------------------------------

_ENCODER = None
try:  # pragma: no cover - environment dependent
    import tiktoken
    _ENCODER = tiktoken.get_encoding("cl100k_base")
except Exception:
    _ENCODER = None


def count_tokens(text: str) -> int:
    if _ENCODER is not None:
        return len(_ENCODER.encode(text, disallowed_special=()))
    return max(1, len(text) // 4)  # calibrated fallback for English news prose


# ---------------------------------------------------------------------------
# Pre-cleaning
# ---------------------------------------------------------------------------

_SCRIPT_BLOCK = re.compile(r"<script\b.*?</script>", re.IGNORECASE | re.DOTALL)
_STYLE_BLOCK = re.compile(r"<style\b.*?</style>", re.IGNORECASE | re.DOTALL)
_HTML_TAG = re.compile(r"<[^>]{1,300}>")
_CSS_BLOB = re.compile(r"[{;][\s]*[a-z-]+\s*:\s*[^;{}]{1,80};")  # rule-like runs
_JS_LINE = re.compile(r"^\s*(?:var |let |const |function\b|window\.|document\.).*$",
                      re.MULTILINE)
_URL_ONLY_LINE = re.compile(r"^\s*https?://\S+\s*$", re.MULTILINE)

_BOILERPLATE_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in (
        r"^\s*(subscribe|sign up|log ?in|newsletter|advertis\w*|sponsored)\b.{0,80}$",
        r"^\s*(accept|manage)\s+(all\s+)?cookies\b.*$",
        r"^\s*©.*$|^\s*copyright\b.*$|^\s*all rights reserved.*$",
        r"^\s*(share (this|on)|follow us)\b.*$",
        r"^\s*(read more|related( articles| stories)?|most popular|trending)\s*:?\s*$",
        r"^\s*photo(graph)?s? (by|:).{0,60}$|^\s*(image|credit)\s*:.{0,60}$",
        r"^\s*loading\.{0,3}\s*$",
    )
]


def clean_text(raw: str) -> str:
    """Remove web cruft and normalize before chunking. Conservative by design:
    when in doubt, keep the line — a stray nav item costs tokens; a deleted
    evidence sentence costs the report."""
    text = _SCRIPT_BLOCK.sub(" ", raw)
    text = _STYLE_BLOCK.sub(" ", text)
    text = _HTML_TAG.sub(" ", text)
    text = _JS_LINE.sub("", text)
    text = _URL_ONLY_LINE.sub("", text)
    # Drop dense CSS-looking regions line by line
    kept_lines: List[str] = []
    seen: dict[str, int] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            kept_lines.append("")
            continue
        if len(_CSS_BLOB.findall(stripped)) >= 3:
            continue
        if any(p.match(stripped) for p in _BOILERPLATE_PATTERNS):
            continue
        # Repeated short lines (menus/footers) — drop from the 3rd repeat on
        if len(stripped) <= 60:
            seen[stripped] = seen.get(stripped, 0) + 1
            if seen[stripped] >= 3:
                continue
        kept_lines.append(line)
    text = "\n".join(kept_lines)

    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\u00ad", "")                     # soft hyphens
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)          # line-break hyphenation
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ---------------------------------------------------------------------------
# Sentence-boundary detection (abbreviation-safe, cheap)
# ---------------------------------------------------------------------------

_ABBREVS = {
    "mr", "mrs", "ms", "dr", "prof", "sen", "rep", "gov", "gen", "col", "sgt",
    "st", "vs", "etc", "inc", "ltd", "corp", "co", "jr", "sr", "no", "fig",
    "approx", "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "sept",
    "oct", "nov", "dec", "u.s", "u.k", "d.c", "e.g", "i.e",
}
_SENT_END = re.compile(r"(?<=[.!?])[\"'”’\)\]]*\s+(?=[\"'“‘\(\[]?[A-Z0-9])")


def _ends_with_abbrev(fragment: str) -> bool:
    last = fragment.rstrip().rstrip(".").rsplit(" ", 1)[-1].lower()
    return last in _ABBREVS


def split_sentences(text: str) -> List[str]:
    sentences: List[str] = []
    for para in text.split("\n\n"):
        para = para.strip()
        if not para:
            continue
        parts = _SENT_END.split(para.replace("\n", " "))
        merged: List[str] = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            if merged and _ends_with_abbrev(merged[-1]):
                merged[-1] = merged[-1] + " " + part  # false boundary: rejoin
            else:
                merged.append(part)
        sentences.extend(merged)
    return sentences


def _hard_split_long_sentence(sentence: str, max_tokens: int) -> List[str]:
    """Last resort for pathological sentences: split on whitespace at token
    boundaries, never mid-word. Measures the JOINED candidate piece each
    step, because summing per-word counts under-estimates with the fallback
    counter and the pieces would overshoot the budget."""
    words = sentence.split(" ")
    pieces: List[str] = []
    current: List[str] = []
    for w in words:
        candidate = " ".join(current + [w])
        if current and count_tokens(candidate) > max_tokens:
            pieces.append(" ".join(current))
            current = [w]
        else:
            current.append(w)
    if current:
        pieces.append(" ".join(current))
    return pieces


# ---------------------------------------------------------------------------
# Token-aware chunking with sentence overlap
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    index: int
    text: str
    token_count: int
    sentence_span: tuple  # (first_sentence_idx, last_sentence_idx) inclusive
    overlap_with_prev: int  # sentences repeated from previous chunk


def chunk_text(
    text: str,
    max_tokens: int = 600,
    overlap_sentences: int = 2,
    pre_clean: bool = True,
) -> List[Chunk]:
    """Sentence-boundary, token-budgeted chunking with overlap.

    The overlap is the co-occurrence guarantee: any evidence span of up to
    `overlap_sentences + 1` sentences appears whole in at least one chunk, so
    tag pairs whose evidence straddles a boundary are still seen together by
    the model. Increase overlap for frameworks whose evidence tends to run
    long; the cost is linear and small.
    """
    if pre_clean:
        text = clean_text(text)
    sentences = split_sentences(text)

    # Explode pathological sentences first so budgeting is honest.
    exploded: List[str] = []
    for s in sentences:
        if count_tokens(s) > max_tokens:
            exploded.extend(_hard_split_long_sentence(s, max_tokens))
        else:
            exploded.append(s)
    sentences = exploded

    chunks: List[Chunk] = []
    i = 0
    while i < len(sentences):
        start = i
        tokens = 0
        current: List[str] = []
        while i < len(sentences):
            t = count_tokens(sentences[i] + " ")
            if current and tokens + t > max_tokens:
                break
            current.append(sentences[i])
            tokens += t
            i += 1
        overlap = min(overlap_sentences, len(current) - 1) if i < len(sentences) else 0
        chunks.append(Chunk(
            index=len(chunks),
            text=" ".join(current),
            token_count=tokens,
            sentence_span=(start, i - 1),
            overlap_with_prev=(start_overlap := 0) if not chunks else chunks[-1].sentence_span[1] - start + 1 if start <= chunks[-1].sentence_span[1] else 0,
        ))
        i -= overlap  # step back to create the overlap window
        if i <= start:  # safety: always advance
            i = start + max(1, len(current))
    return chunks


# ---------------------------------------------------------------------------
# Language / script detection
# ---------------------------------------------------------------------------

_RTL_RANGES = ((0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF))


@dataclass
class ScriptReport:
    non_latin_ratio: float
    rtl_ratio: float
    is_rtl: bool
    language: Optional[str]  # ISO 639-1 guess or None
    recommendation: str = field(default="")


def detect_script(text: str, sample_chars: int = 4000) -> ScriptReport:
    sample = text[:sample_chars]
    letters = [c for c in sample if c.isalpha()]
    if not letters:
        return ScriptReport(0.0, 0.0, False, None, "empty_or_symbolic:skip")
    non_latin = sum(1 for c in letters if not ("LATIN" in unicodedata.name(c, "")))
    rtl = sum(1 for c in letters if any(a <= ord(c) <= b for a, b in _RTL_RANGES))
    non_latin_ratio = non_latin / len(letters)
    rtl_ratio = rtl / len(letters)
    language = None
    try:  # optional dependency
        from langdetect import detect
        language = detect(sample)
    except Exception:
        pass
    is_rtl = rtl_ratio > 0.30
    if is_rtl:
        rec = "rtl:route_to_multilingual_lane_or_skip"
    elif language and language != "en":
        rec = f"non_english({language}):route_to_multilingual_lane_or_skip"
    elif non_latin_ratio > 0.5:
        rec = "non_latin:route_to_multilingual_lane_or_skip"
    else:
        rec = "english:process"
    return ScriptReport(round(non_latin_ratio, 3), round(rtl_ratio, 3),
                        is_rtl, language, rec)
