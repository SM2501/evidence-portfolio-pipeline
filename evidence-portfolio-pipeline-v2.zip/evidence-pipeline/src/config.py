"""
src/config.py — Central configuration and the hard-coded 12-tag vocabulary.
===========================================================================
Every module reads the framework from here; nothing redefines it locally.
"""

from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# The 12-tag classification framework (tag 12 is the SCOPE pair)
# ---------------------------------------------------------------------------

CONTENT_TAGS: dict[str, str] = {
    "TAPER_HARM":          "Documented adverse outcome attributed to dose reduction or discontinuation.",
    "VETERAN_SUICIDE":     "Veteran suicide or suicidal ideation in a pain-care/VA context.",
    "GUIDELINE_CRITIQUE":  "Challenge to the evidence base or application of CDC/VA/state guidelines.",
    "GUIDELINE_DEFENSE":   "Official or expert defense of restrictive guidelines/policies.",
    "KRATOM_POLICY":       "Kratom or 7-OH regulatory action or debate.",
    "PATIENT_ABANDONMENT": "Loss of care access without clinical justification.",
    "STIGMA":              "Stigmatizing framing or documented discrimination.",
    "DISPLACEMENT":        "Movement to illicit or gray-market supply after legal access ended.",
    "DATA_LIMITATION":     "Critique or misuse of surveillance data.",
    "PERSONAL_ACCOUNT":    "First-person or family-member narrative is central.",
    "POLICY_TENSION":      "Conflict between policies, agencies, or stated goals.",
}

SCOPE_TAGS: dict[str, str] = {
    "SCOPE_LOCAL":    "Local/regional outlet or single-state focus.",
    "SCOPE_NATIONAL": "National outlet or multi-state framing.",
}

# All assignable tag strings (11 content + 2 scope alternatives = 13 strings
# expressing the 12-tag framework; SCOPE is one tag with two mutually
# exclusive values).
ALL_TAGS: dict[str, str] = {**CONTENT_TAGS, **SCOPE_TAGS}
ALLOWED_TAG_STRINGS: list[str] = list(ALL_TAGS.keys())

# SCOPE rule: any chunk that receives at least one content tag must carry
# EXACTLY ONE scope tag. A chunk with no relevant content (empty tags) is
# exempt — demanding a scope for irrelevant text would manufacture noise.
E_SCOPE = "E_SCOPE"

# ---------------------------------------------------------------------------
# Model endpoint (OpenAI-compatible vLLM on RunPod)
# ---------------------------------------------------------------------------

RUNPOD_BASE_URL = os.getenv("RUNPOD_BASE_URL", "")
RUNPOD_API_KEY = os.getenv("RUNPOD_API_KEY", "")
MODEL_NAME = os.getenv("RUNPOD_MODEL", "meta-llama/Llama-4-Scout-17B-16E-Instruct")

# ---------------------------------------------------------------------------
# Pipeline knobs
# ---------------------------------------------------------------------------

MAX_TOKENS_PER_CHUNK = 600
OVERLAP_SENTENCES = 2
MAX_LLM_ATTEMPTS = 3           # 1 try + 2 prompt-mutating retries
WORKERS = 8
QUEUE_MAXSIZE = 32

# ---------------------------------------------------------------------------
# Paths (all overridable for tests)
# ---------------------------------------------------------------------------

DATA_DIR = Path(os.getenv("PIPELINE_DATA_DIR", "data"))
ARCHIVE_DIR = DATA_DIR / "archive"          # content-addressed article texts
GRAPH_DIR = DATA_DIR / "graph_out"          # per-article node/edge JSON
DB_PATH = DATA_DIR / "pipeline_state.db"
TRIAGE_PATH = DATA_DIR / "triage_queue.jsonl"
VERIFICATION_LOG = DATA_DIR / "verification_log.jsonl"
OCR_AUDIT_LOG = DATA_DIR / "ocr_pages.log.jsonl"

AUDIT_KEY_PATH = Path(os.getenv(
    "PIPELINE_AUDIT_KEY", str(Path.home() / ".pipeline" / "audit_key")))


def ensure_dirs() -> None:
    for d in (DATA_DIR, ARCHIVE_DIR, GRAPH_DIR):
        d.mkdir(parents=True, exist_ok=True)
