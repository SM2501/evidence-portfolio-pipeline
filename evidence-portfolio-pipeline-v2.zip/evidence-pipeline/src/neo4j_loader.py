"""
neo4j_loader.py — Injection-safe, batch-tuned Neo4j loading.
=============================================================
Section 3 of the pipeline redesign.

Three rules, none optional:
  1. PARAMETERS ONLY. Every value travels in the `parameters` dict of
     `session.run(query, parameters)`. The only string composition permitted
     is choosing a label/relationship type from a hard-coded WHITELIST —
     Cypher cannot parameterize labels, so the whitelist is the fence.
  2. Nodes MERGE on id; relationships MATCH both endpoints (never MERGE
     endpoints), so a bad edge can never materialize a phantom, property-less
     node that would bypass the epistemic_status whitelist.
  3. Batches are sized dynamically by estimated payload bytes, not row count,
     because "20–100 entities per article" hides a 50× spread in row size.
"""

from __future__ import annotations

import json
from typing import Dict, Iterable, List, Sequence

# Hard-coded whitelists — extend deliberately, in code review, never at runtime.
ALLOWED_LABELS = frozenset({
    "Substance", "Policy", "Jurisdiction", "Outcome", "Regulatory_Actor",
    "Corporate_Actor", "Media_Outlet", "Media_Trope", "Narrative_Frame",
    "Data_Artifact", "Measurement_Metric", "Epistemic_Claim", "ResearchGap",
    "TemporalEvent", "Funding_Source", "Industry_Faction", "Deceptive_Practice",
    "Intervention", "Litigation", "Oversight_Agency", "Systemic_Failure",
    "Carceral_Mechanism", "Social_Determinant", "Vulnerable_Population",
    "LivedExperience", "Stigma", "EthicalPrinciple", "HarmReductionPrinciple",
    "Survival_Strategy", "Alkaloid_Metabolite", "Receptor", "Receptor_Profile",
    "Physiological_Effect", "Metabolic_Pathway", "Systemic_Action",
    "Manufactured_Trope", "Data_Vulnerability", "Concept",
    "ArticleAnalysisSource", "Article", "Evidence", "Tag",
})
ALLOWED_REL_TYPES = frozenset({
    "ASSERTS", "DISPUTES", "CONTRADICTS", "OVERRIDES", "METABOLIZES_INTO",
    "LEADS_TO", "CONCEALED_RISK_OF", "FAILS_STANDARD_OF", "CRIMINALIZES",
    "WEAPONIZES_TERM", "MITIGATES", "DRIVES_DEMAND_FOR", "TARGETS", "CITED",
    "ADDS_CONTEXT_TO", "FUNDS", "AMPLIFIES", "EXHIBITS", "UTILIZES",
    "EXTRACTED_FROM", "IS_SAME_ENTITY_AS", "TAGGED", "UNKNOWN",
})


class LabelNotAllowed(ValueError):
    pass


def _check_label(label: str) -> str:
    if label not in ALLOWED_LABELS:
        raise LabelNotAllowed(f"Label {label!r} is not whitelisted; "
                              "add it in code review or map it to Concept.")
    return label


def _check_rel(rel: str) -> str:
    if rel not in ALLOWED_REL_TYPES:
        return "UNKNOWN"  # degrade, don't inject; original kept in properties
    return rel


# ---------------------------------------------------------------------------
# Schema constraints — run once at deploy
# ---------------------------------------------------------------------------

CONSTRAINT_STATEMENTS = [
    # One node per (label, id): the dedupe backbone across chunk extractions.
    *(f"CREATE CONSTRAINT uniq_{label.lower()}_id IF NOT EXISTS "
      f"FOR (n:`{label}`) REQUIRE n.id IS UNIQUE" for label in sorted(ALLOWED_LABELS)),
    "CREATE INDEX idx_epistemic_status IF NOT EXISTS FOR (n:Entity) ON (n.epistemic_status)",
]


def setup_constraints(driver) -> None:
    with driver.session() as session:
        for stmt in CONSTRAINT_STATEMENTS:
            session.run(stmt)  # DDL contains only whitelisted literals


# ---------------------------------------------------------------------------
# Dynamic batch sizing by payload bytes
# ---------------------------------------------------------------------------

TARGET_BATCH_BYTES = 3 * 1024 * 1024   # ~3 MB/tx: safe for 32 GB local Neo4j
MIN_BATCH_ROWS = 100
MAX_BATCH_ROWS = 2000


def dynamic_batches(rows: Sequence[dict],
                    target_bytes: int = TARGET_BATCH_BYTES) -> Iterable[List[dict]]:
    """Yield batches sized by estimated serialized bytes. Row-count batching
    fails here because a node with two properties and a node with a paragraph
    of evidence differ by 50×; byte batching keeps transaction memory flat."""
    batch: List[dict] = []
    batch_bytes = 0
    for row in rows:
        row_bytes = len(json.dumps(row, default=str))
        if batch and (
            batch_bytes + row_bytes > target_bytes or len(batch) >= MAX_BATCH_ROWS
        ) and len(batch) >= MIN_BATCH_ROWS:
            yield batch
            batch, batch_bytes = [], 0
        # A single oversize row still ships alone rather than stalling.
        if batch and batch_bytes + row_bytes > target_bytes and len(batch) < MIN_BATCH_ROWS:
            pass  # keep filling to MIN_BATCH_ROWS; 3MB target is soft, 32GB heap is not
        batch.append(row)
        batch_bytes += row_bytes
    if batch:
        yield batch


# ---------------------------------------------------------------------------
# Parameterized load queries
# ---------------------------------------------------------------------------

NODE_MERGE_QUERY = """
UNWIND $rows AS row
MERGE (n:`{label}` {{id: row.id}})
ON CREATE SET
    n += row.props,
    n.epistemic_status = row.epistemic_status,
    n.first_seen = timestamp(),
    n.source_files = [row.source_file]
ON MATCH SET
    n.descriptions = CASE
        WHEN row.props.description IS NOT NULL
             AND NOT coalesce(row.props.description, '') IN coalesce(n.descriptions, [])
        THEN coalesce(n.descriptions, []) + row.props.description
        ELSE n.descriptions END,
    n.source_files = CASE
        WHEN NOT row.source_file IN coalesce(n.source_files, [])
        THEN coalesce(n.source_files, []) + row.source_file
        ELSE n.source_files END,
    n.last_seen = timestamp()
"""

EDGE_MATCH_QUERY = """
UNWIND $rows AS row
MATCH (a {{id: row.source}})
MATCH (b {{id: row.target}})
MERGE (a)-[r:`{rel}` {{source_file: row.source_file}}]->(b)
ON CREATE SET r += row.props,
              r.epistemic_status = row.epistemic_status,
              r.original_type = row.original_type,
              r.created = timestamp()
RETURN count(r) AS created
"""

DANGLING_EDGE_QUERY = """
UNWIND $rows AS row
OPTIONAL MATCH (a {id: row.source})
OPTIONAL MATCH (b {id: row.target})
WITH row, a, b WHERE a IS NULL OR b IS NULL
RETURN row.source AS source, row.target AS target
"""


def load_nodes(driver, nodes: Sequence[dict]) -> int:
    """Nodes grouped by whitelisted label; values only ever in $rows."""
    total = 0
    by_label: Dict[str, List[dict]] = {}
    for n in nodes:
        by_label.setdefault(_check_label(n.get("label", "Concept")), []).append({
            "id": n["id"],
            "props": n.get("properties", {}),
            "epistemic_status": n.get("properties", {}).get(
                "epistemic_status", "llm_provisional"),
            "source_file": n.get("_source_file", "unknown"),
        })
    with driver.session() as session:
        for label, rows in by_label.items():
            query = NODE_MERGE_QUERY.format(label=label)  # label is whitelisted
            for batch in dynamic_batches(rows):
                session.execute_write(lambda tx: tx.run(query, rows=batch).consume())
                total += len(batch)
    return total


def load_edges(driver, edges: Sequence[dict]) -> Dict[str, int]:
    """Edges MATCH endpoints; dangling references are reported, never created."""
    stats = {"created": 0, "dangling": 0}
    by_rel: Dict[str, List[dict]] = {}
    for e in edges:
        rel = _check_rel(e.get("type", "UNKNOWN"))
        by_rel.setdefault(rel, []).append({
            "source": e["source"],
            "target": e["target"],
            "props": e.get("properties", {}),
            "original_type": e.get("type", "UNKNOWN"),
            "epistemic_status": e.get("properties", {}).get(
                "epistemic_status", "llm_provisional"),
            "source_file": e.get("_source_file", "unknown"),
        })
    with driver.session() as session:
        for rel, rows in by_rel.items():
            query = EDGE_MATCH_QUERY.format(rel=rel)  # rel is whitelisted
            for batch in dynamic_batches(rows):
                dangling = session.execute_read(
                    lambda tx: [dict(r) for r in tx.run(DANGLING_EDGE_QUERY, rows=batch)])
                stats["dangling"] += len(dangling)
                session.execute_write(lambda tx: tx.run(query, rows=batch).consume())
                stats["created"] += len(batch) - len(dangling)
    return stats
