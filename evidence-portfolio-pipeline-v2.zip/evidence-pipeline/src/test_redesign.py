"""
src/test_redesign.py — Full test suite: unit checks + mock end-to-end run.
==========================================================================
Run from the repo root:  python -m src.test_redesign
Uses a temp data dir; never touches real pipeline state or ~/.pipeline.
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

# Isolate all pipeline state before importing config
_TMP = Path(tempfile.mkdtemp(prefix="pipeline_test_"))
os.environ["PIPELINE_DATA_DIR"] = str(_TMP / "data")
os.environ["PIPELINE_AUDIT_KEY"] = str(_TMP / "audit_key")

from src import config                                    # noqa: E402
from src.audit_verifier import SignedVerificationLog, verify_log   # noqa: E402
from src.checkpoint import CheckpointStore                # noqa: E402
from src.extraction_prompt import (build_system_prompt, enforce_framework,
                                   verify_quotes)         # noqa: E402
from src.json_repair import enforce_schema, extract_and_repair      # noqa: E402
from src.llm_client import MockLLMClient                  # noqa: E402
from src.neo4j_loader import (ALLOWED_LABELS, _check_label, _check_rel,
                              dynamic_batches, LabelNotAllowed)      # noqa: E402
from src.ocr_fallback import clean_ocr_text               # noqa: E402
from src.pipeline_orchestrator import run_pipeline        # noqa: E402
from src.rate_controller import (AdaptiveRateController, ControllerConfig,
                                 parse_vllm_metrics)      # noqa: E402
from src.text_cleaning import (chunk_text, clean_text, count_tokens,
                               detect_script, split_sentences)       # noqa: E402

passed = 0
def ok(msg):
    global passed
    passed += 1
    print(f"{passed:2d}. {msg}")

# ============ text_cleaning ============
dirty = ("<script>var x=1;</script>\nSubscribe to our newsletter!\n"
         "Accept all cookies\n\nDr. Smith of the U.S. CDC said the taper "
         "policy failed. Deaths rose 8%. A third study found no effect.\n\n"
         "© 2026 Example Media.")
cleaned = clean_text(dirty)
assert "var x" not in cleaned and "Subscribe" not in cleaned and "©" not in cleaned
assert "taper policy failed" in cleaned
ok("pre-cleaning strips script/boilerplate, keeps evidence")

assert len(split_sentences("Dr. Smith of the U.S. CDC disagreed. Mr. Jones concurred. It rose 5%.")) == 3
ok("abbreviation-safe sentence splitting")

long_text = " ".join(f"Sentence {i} concerns taper policy outcomes and access." for i in range(120))
chs = chunk_text(long_text, max_tokens=120, overlap_sentences=2, pre_clean=False)
assert all(c.token_count <= 120 for c in chs)
sets_ = [set(c.text.split(". ")) for c in chs]
assert all(sets_[i] & sets_[i + 1] for i in range(len(sets_) - 1))
ok(f"token-budgeted chunking with overlap ({len(chs)} chunks)")

assert detect_script("قالت الوزارة إن السياسة فشلت هذا العام في جميع المناطق").is_rtl
ok("RTL routing detection")

# ============ json_repair + framework ============
r = extract_and_repair('Here you go:\n{tags: ["TAPER_HARM", "SCOPE_LOCAL",], '
                       '"evidence_quotes": ["x"], "rationale": "r", confidence: 0.7,}')
assert r.ok and "quoted_unquoted_keys" in r.repairs
s = enforce_schema(r.data, config.ALLOWED_TAG_STRINGS)
assert s.ok and s.data["tags"] == ["TAPER_HARM", "SCOPE_LOCAL"]
ok("repair + schema against the real 12-tag vocabulary")

assert enforce_framework({"tags": ["TAPER_HARM"]})              # missing scope
assert enforce_framework({"tags": ["SCOPE_LOCAL"]})             # scope w/o content
assert enforce_framework({"tags": ["TAPER_HARM", "SCOPE_LOCAL",
                                   "SCOPE_NATIONAL"]})          # two scopes
assert not enforce_framework({"tags": ["STIGMA", "SCOPE_NATIONAL"]})
assert not enforce_framework({"tags": []})
ok("SCOPE pair rule: exactly one when content tags present")

assert verify_quotes({"evidence_quotes": ["real words", "invented"]},
                     "chunk has real words only") == ["invented"]
ok("verbatim-quote hallucination check")

# ============ prompt ============
sp = build_system_prompt()
assert all(t in sp for t in config.ALL_TAGS) and count_tokens(sp) < 2200
ok(f"system prompt carries all 13 tag strings (~{count_tokens(sp)} tokens)")

# ============ neo4j_loader ============
assert "Article" in ALLOWED_LABELS and _check_rel("TAGGED") == "TAGGED"
assert _check_rel("DROP DATABASE") == "UNKNOWN"
try:
    _check_label("Evil`) DETACH DELETE (n")
    raise SystemExit("FAIL: label injection")
except LabelNotAllowed:
    pass
big = [{"id": f"n{i}", "p": "y" * 40_000} for i in range(400)]
assert sum(len(b) for b in dynamic_batches(big)) == 400
ok("graph whitelist + byte-sized batching + injection blocked")

# ============ rate controller ============
async def rc():
    c = AdaptiveRateController(ControllerConfig(initial_concurrent=8,
                                                window_seconds=0.01))
    for _ in range(40):
        c.record_latency(0.5)
    c.observe_metrics(parse_vllm_metrics("vllm:num_requests_waiting 30\n"))
    return c.limit
assert asyncio.run(rc()) < 8
ok("AIMD decrease on congested vLLM metrics")

# ============ OCR cleanup ============
assert "412 deaths in 2025" in clean_ocr_text("4l2 deaths in 2O25.")
ok("OCR digit-confusion cleanup")

# ============ END-TO-END: mock run over a 3-document corpus ============
corpus = _TMP / "corpus"
corpus.mkdir()
(corpus / "doc1_taper_local.txt").write_text(
    "The county clinic began a rapid taper program last spring.\n\n"
    "Ms. Rivera said the dose reduction left her in withdrawal and unable "
    "to work. She said her pharmacist refused to fill the remainder.\n\n"
    "A local physician called the outcome predictable given the policy.",
    encoding="utf-8")
(corpus / "doc2_kratom_malformed.txt").write_text(
    "MALFORMED_TRIGGER National regulators opened a multi-state review of "
    "kratom products this week.\n\nIndustry groups disputed the agency's "
    "framing of the national data.",
    encoding="utf-8")
(corpus / "doc3_veteran_hallucinated.txt").write_text(
    "HALLUCINATE_TRIGGER A veteran described suicidal ideation after his "
    "pain care was cut at the regional VA clinic.\n\nHis family said the "
    "clinic offered no follow-up plan.",
    encoding="utf-8")

client = MockLLMClient()
summary1 = asyncio.run(run_pipeline(corpus, client, workers=3))
assert summary1["articles_by_state"].get("extracted") == 3, summary1
assert summary1["chunks_needing_repair"] >= 1          # doc2's malformed reply
first_run_calls = client.calls
ok(f"mock pipeline run: 3 articles extracted in {first_run_calls} LLM calls")

# Repairs recorded for the malformed doc
store = CheckpointStore(config.DB_PATH)
assert store.summary()["chunks_needing_repair"] >= 1
ok("repair metrics tracked per chunk")

# Triage: hallucinated quote routed; quarantined out of payload
triage = [json.loads(l) for l in
          config.TRIAGE_PATH.read_text().splitlines()]
halluc_items = [t for t in triage
                if any(c.startswith("E_QUOTE_NOT_IN_SOURCE") for c in t["codes"])]
assert halluc_items, triage
assert all("cancelled entirely" not in q
           for t in halluc_items if t["result"]
           for q in t["result"]["evidence_quotes"])
ok("hallucinated quote routed to triage and quarantined from payload")

# Graph output: whitelisted labels, provisional statuses, EXTRACTED_FROM
graphs = list(config.GRAPH_DIR.glob("*.json"))
assert len(graphs) == 3
g = json.loads(graphs[0].read_text())
assert all(n["label"] in ALLOWED_LABELS for n in g["nodes"])
assert any(e["type"] == "EXTRACTED_FROM" for e in g["edges"])
ev = [n for n in g["nodes"] if n["label"] == "Evidence"]
assert all(n["properties"]["epistemic_status"] == "llm_provisional" for n in ev)
tagged = [n for n in g["nodes"] if n["label"] == "Tag"]
assert all(t["id"] in config.ALL_TAGS for t in tagged)
ok(f"graph rows valid: {len(graphs)} articles, labels whitelisted, provisional")

# Resume: second run performs ZERO new LLM calls (everything checkpointed)
summary2 = asyncio.run(run_pipeline(corpus, client, workers=3))
assert client.calls == first_run_calls, (client.calls, first_run_calls)
assert summary2["duplicates"] == 3
ok("idempotent resume: re-run makes 0 LLM calls, corpus deduped")

# Crash-resume: delete one chunk result, re-run, exactly the gap is redone
with store._conn() as conn:
    victim = conn.execute("SELECT article_id, chunk_index FROM chunk_results "
                          "WHERE status='done' LIMIT 1").fetchone()
    conn.execute("DELETE FROM chunk_results WHERE article_id=? AND chunk_index=?",
                 (victim["article_id"], victim["chunk_index"]))
store.finish_article(victim["article_id"], state="chunked")
asyncio.run(run_pipeline(corpus, client, workers=3))
assert client.calls == first_run_calls + 1
assert not store.pending_chunks(victim["article_id"])
ok("crash-resume: exactly the missing chunk was recomputed (1 extra call)")

# Signed verification: decision requires rationale; tamper detected
config.AUDIT_KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
config.AUDIT_KEY_PATH.write_bytes(b"k" * 64)
vlog = SignedVerificationLog(config.VERIFICATION_LOG, config.AUDIT_KEY_PATH)
try:
    vlog.append(reviewer_id="AB", action="approve", article_id="a",
                claim_ref="chunk[0]", evidence_text="e", rationale="   ")
    raise SystemExit("FAIL: empty rationale accepted")
except ValueError:
    pass
vlog.append(reviewer_id="AB", action="approve",
            article_id=triage[0]["article_id"], claim_ref="chunk[0]",
            evidence_text=json.dumps(triage[0]["result"]),
            rationale="checked quote against archived source text")
head = vlog.head()
assert verify_log(config.VERIFICATION_LOG, config.AUDIT_KEY_PATH, head).ok
lines = config.VERIFICATION_LOG.read_text().splitlines()
e = json.loads(lines[0]); e["rationale"] = "rewritten"
tampered = _TMP / "tampered.jsonl"
tampered.write_text(json.dumps(e) + "\n")
assert not verify_log(tampered, config.AUDIT_KEY_PATH).ok
ok("signed decisions: rationale mandatory; tampering detected")

print(f"\nALL {passed} CHECKS PASSED")
shutil.rmtree(_TMP, ignore_errors=True)
