"""
ocr_fallback.py — Scanned-PDF detection, OCR fallback, and OCR cleanup.
=======================================================================
Section 5 of the pipeline redesign.

Rule: if PyMuPDF extracts fewer than MIN_CHARS_PER_PAGE characters from a
page, that page is treated as scanned and rendered at 300 DPI for
pytesseract. Detection is PER PAGE, not per document — mixed documents
(typed report + scanned appendix) are common in policy PDFs.

Every OCR'd page is logged with its confidence estimate so a human can audit
exactly which evidence passed through the lossier channel. Evidence quotes
that originate from OCR'd pages should carry an `ocr: true` flag downstream
— reviewers must know they may be checking against imperfect text.

Dependencies: pymupdf, pytesseract, Pillow, and the tesseract binary
(apt install tesseract-ocr).
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional

log = logging.getLogger("ocr_fallback")

MIN_CHARS_PER_PAGE = 100
OCR_DPI = 300
LOW_CONFIDENCE = 60.0  # mean tesseract word confidence below this → flag


# ---------------------------------------------------------------------------
# OCR text cleanup — conservative regex passes for classic scanner errors
# ---------------------------------------------------------------------------

_LIGATURES = {"ﬁ": "fi", "ﬂ": "fl", "ﬀ": "ff", "ﬃ": "ffi", "ﬄ": "ffl"}
# digit-context confusions: l/I inside numbers, O inside numbers
_L_IN_NUMBER = re.compile(r"(?<=\d)[lI](?=\d)")
_O_IN_NUMBER = re.compile(r"(?<=\d)[Oo](?=\d)")
_ONE_AS_L = re.compile(r"\b[lI](?=\d{2,}\b)")
_BROKEN_WORD = re.compile(r"(\w)-\s*\n\s*(\w)")
_GIBBERISH_LINE = re.compile(r"^[^A-Za-z0-9]{6,}$")


def clean_ocr_text(text: str) -> str:
    for lig, replacement in _LIGATURES.items():
        text = text.replace(lig, replacement)
    text = _BROKEN_WORD.sub(r"\1\2", text)
    text = _L_IN_NUMBER.sub("1", text)
    text = _O_IN_NUMBER.sub("0", text)
    text = _ONE_AS_L.sub("1", text)
    lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if _GIBBERISH_LINE.match(stripped):
            continue
        # drop lines that are mostly non-alphanumeric noise
        if stripped and sum(c.isalnum() or c.isspace() for c in stripped) / len(stripped) < 0.5:
            continue
        lines.append(line)
    text = "\n".join(lines)
    return re.sub(r"[ \t]{2,}", " ", text).strip()


# Optional: a focused small-model cleanup pass for high-value pages. Kept as
# an explicit function so its use is a deliberate (and logged) choice — LLM
# "cleanup" can also silently rewrite evidence, so it is OFF by default and
# must never touch pages whose text will be quoted verbatim without review.
OCR_CLEANUP_PROMPT = (
    "The following text was produced by OCR of a scanned document. Fix ONLY "
    "obvious character-level scanning errors (confused l/1/I, O/0, split or "
    "hyphenated words, ligatures). Do NOT paraphrase, reorder, summarize, or "
    "add words. Preserve line breaks. Output only the corrected text."
)


# ---------------------------------------------------------------------------
# Extraction with per-page fallback
# ---------------------------------------------------------------------------

@dataclass
class PageResult:
    page: int
    method: str            # "native" | "ocr"
    chars: int
    ocr_confidence: Optional[float] = None
    flagged_low_confidence: bool = False


@dataclass
class PdfExtraction:
    path: str
    text: str
    pages: List[PageResult] = field(default_factory=list)

    @property
    def ocr_pages(self) -> List[int]:
        return [p.page for p in self.pages if p.method == "ocr"]


def extract_pdf_text(pdf_path: str | Path,
                     ocr_audit_log: str | Path = "ocr_pages.log.jsonl",
                     min_chars: int = MIN_CHARS_PER_PAGE) -> PdfExtraction:
    """Native text extraction with automatic per-page OCR fallback."""
    import fitz  # PyMuPDF
    pdf_path = Path(pdf_path)
    doc = fitz.open(pdf_path)
    page_texts: List[str] = []
    results: List[PageResult] = []

    for page_number, page in enumerate(doc):
        native = page.get_text("text") or ""
        if len(native.strip()) >= min_chars:
            page_texts.append(native)
            results.append(PageResult(page_number, "native", len(native)))
            continue

        # --- OCR fallback ---
        try:
            import pytesseract
            from PIL import Image
            zoom = OCR_DPI / 72.0
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
            image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            data = pytesseract.image_to_data(
                image, output_type=pytesseract.Output.DICT)
            words = [w for w in data["text"] if w.strip()]
            confs = [float(c) for c, w in zip(data["conf"], data["text"])
                     if w.strip() and float(c) >= 0]
            ocr_text = clean_ocr_text(" ".join(words))
            mean_conf = round(sum(confs) / len(confs), 1) if confs else 0.0
            flagged = mean_conf < LOW_CONFIDENCE
            page_texts.append(ocr_text)
            results.append(PageResult(page_number, "ocr", len(ocr_text),
                                      mean_conf, flagged))
            log.info("OCR page %d of %s: %d chars, conf=%.1f%s",
                     page_number, pdf_path.name, len(ocr_text), mean_conf,
                     " [LOW CONFIDENCE]" if flagged else "")
        except Exception as exc:
            log.error("OCR failed on page %d of %s: %s",
                      page_number, pdf_path.name, exc)
            page_texts.append(native)  # keep whatever native gave us
            results.append(PageResult(page_number, "native", len(native)))

    doc.close()
    extraction = PdfExtraction(str(pdf_path), "\n\n".join(page_texts), results)

    # Append per-page audit records for every OCR'd page
    if extraction.ocr_pages:
        with Path(ocr_audit_log).open("a", encoding="utf-8") as f:
            for r in extraction.pages:
                if r.method == "ocr":
                    f.write(json.dumps({"pdf": str(pdf_path), **asdict(r)}) + "\n")
    return extraction
