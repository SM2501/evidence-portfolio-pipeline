"""
checkpoint.py — Per-article, per-chunk checkpointing with exact resume.
=======================================================================
Section 7 of the pipeline redesign.

One SQLite file is the work queue AND the checkpoint store. State advances
per CHUNK, not per article, so a crash mid-article loses at most one LLM
call. Identity is the article's content sha256, so re-queuing the same
corpus is a no-op and a silently-changed source is a visibly new article.

Resume is not a feature; it's the absence of one: every run simply asks the
store for work that isn't done. (For S3 durability, sync the .db file after
each run — SQLite files copy safely when no writer is active.)
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    article_id   TEXT PRIMARY KEY,          -- sha256 of content
    source_url   TEXT,
    state        TEXT NOT NULL DEFAULT 'queued'
                 CHECK (state IN ('queued','chunked','extracting',
                                  'extracted','loaded','failed','skipped_duplicate')),
    n_chunks     INTEGER,
    error        TEXT,
    updated_at   REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chunk_results (
    article_id   TEXT NOT NULL REFERENCES articles(article_id),
    chunk_index  INTEGER NOT NULL,
    status       TEXT NOT NULL CHECK (status IN ('done','failed')),
    payload      TEXT,                      -- extraction JSON (done) or error (failed)
    repairs      TEXT,                      -- json_repair record, for drift metrics
    tokens_in    INTEGER DEFAULT 0,
    tokens_out   INTEGER DEFAULT 0,
    updated_at   REAL NOT NULL,
    PRIMARY KEY (article_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_articles_state ON articles(state);
"""


class CheckpointStore:
    def __init__(self, db_path: str | Path = "pipeline_state.db"):
        self.db_path = str(db_path)
        with self._conn() as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")   # crash-safe, concurrent readers
        conn.execute("PRAGMA synchronous=NORMAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ---------------- enqueue / dedupe ----------------

    def enqueue(self, article_id: str, source_url: str = "") -> bool:
        """Returns False if this content hash was already enqueued (dedupe)."""
        with self._conn() as conn:
            cur = conn.execute(
                "INSERT OR IGNORE INTO articles (article_id, source_url, updated_at) "
                "VALUES (?, ?, ?)", (article_id, source_url, time.time()))
            return cur.rowcount == 1

    def set_chunk_count(self, article_id: str, n_chunks: int) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE articles SET n_chunks=?, state='chunked', updated_at=? "
                "WHERE article_id=?", (n_chunks, time.time(), article_id))

    # ---------------- per-chunk checkpointing ----------------

    def pending_chunks(self, article_id: str) -> List[int]:
        """Exactly the chunks NOT already done — the resume primitive."""
        with self._conn() as conn:
            row = conn.execute("SELECT n_chunks FROM articles WHERE article_id=?",
                               (article_id,)).fetchone()
            if row is None or row["n_chunks"] is None:
                return []
            done = {r["chunk_index"] for r in conn.execute(
                "SELECT chunk_index FROM chunk_results "
                "WHERE article_id=? AND status='done'", (article_id,))}
            return [i for i in range(row["n_chunks"]) if i not in done]

    def record_chunk(self, article_id: str, chunk_index: int, *,
                     payload: Optional[dict], repairs: Optional[list] = None,
                     error: Optional[str] = None,
                     tokens_in: int = 0, tokens_out: int = 0) -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO chunk_results "
                "(article_id, chunk_index, status, payload, repairs, "
                " tokens_in, tokens_out, updated_at) VALUES (?,?,?,?,?,?,?,?)",
                (article_id, chunk_index,
                 "done" if error is None else "failed",
                 json.dumps(payload) if payload is not None else error,
                 json.dumps(repairs or []),
                 tokens_in, tokens_out, time.time()))

    def finish_article(self, article_id: str, state: str = "extracted",
                       error: Optional[str] = None) -> None:
        with self._conn() as conn:
            conn.execute("UPDATE articles SET state=?, error=?, updated_at=? "
                         "WHERE article_id=?",
                         (state, error, time.time(), article_id))

    # ---------------- resume / reporting ----------------

    def claim_work(self, limit: int = 50) -> List[str]:
        """Articles that still need extraction, oldest first."""
        with self._conn() as conn:
            return [r["article_id"] for r in conn.execute(
                "SELECT article_id FROM articles "
                "WHERE state IN ('queued','chunked','extracting') "
                "ORDER BY updated_at ASC LIMIT ?", (limit,))]

    def article_results(self, article_id: str) -> Iterator[dict]:
        with self._conn() as conn:
            for r in conn.execute(
                    "SELECT chunk_index, payload FROM chunk_results "
                    "WHERE article_id=? AND status='done' ORDER BY chunk_index",
                    (article_id,)):
                yield json.loads(r["payload"])

    def summary(self) -> dict:
        with self._conn() as conn:
            by_state = {r["state"]: r["n"] for r in conn.execute(
                "SELECT state, COUNT(*) AS n FROM articles GROUP BY state")}
            tokens = conn.execute(
                "SELECT COALESCE(SUM(tokens_in),0) AS tin, "
                "COALESCE(SUM(tokens_out),0) AS tout FROM chunk_results").fetchone()
            repairs = conn.execute(
                "SELECT COUNT(*) AS n FROM chunk_results "
                "WHERE repairs IS NOT NULL AND repairs != '[]'").fetchone()
        return {"articles_by_state": by_state,
                "tokens_in": tokens["tin"], "tokens_out": tokens["tout"],
                "chunks_needing_repair": repairs["n"]}
