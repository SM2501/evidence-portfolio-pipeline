"""
rate_controller.py — Adaptive concurrency for a vLLM endpoint.
==============================================================
Section 6 of the pipeline redesign.

The failure mode being designed against: a fixed semaphore tuned on a quiet
endpoint melts down under load — latency rises, timeouts fire, Tenacity
retries multiply the offered load (thundering herd), the queue deepens, and
P99 goes vertical. The controller breaks that loop three ways:

  1. AIMD (additive-increase / multiplicative-decrease), the TCP congestion
     algorithm, driven by BOTH observed P99 latency and vLLM's own
     /metrics (queue depth `vllm:num_requests_waiting`, KV-cache pressure
     `vllm:gpu_cache_usage_perc`). Metrics scraping is best-effort: if
     /metrics is unreachable, latency alone still steers.
  2. A retry BUDGET: retries may consume at most 10% of recent request
     slots. Beyond that, new retries wait — converting a herd into a queue.
  3. Decrease-on-timeout is immediate and shared, so one worker's timeout
     backs everyone off at once instead of each worker discovering the
     cliff independently.

Start value for an H100/Scout-17B endpoint: max_concurrent=16 (see the audit
document for the sizing math); the controller will find the true ceiling.
"""

from __future__ import annotations

import asyncio
import re
import time
from collections import deque
from dataclasses import dataclass


@dataclass
class ControllerConfig:
    min_concurrent: int = 2
    max_concurrent: int = 64
    initial_concurrent: int = 16
    target_p99_seconds: float = 5.0
    queue_depth_ceiling: int = 8       # vllm:num_requests_waiting above this = congested
    kv_cache_ceiling: float = 0.90     # gpu_cache_usage_perc above this = congested
    increase_step: int = 1             # additive increase per healthy window
    decrease_factor: float = 0.6       # multiplicative decrease when congested
    window_seconds: float = 10.0
    retry_budget_ratio: float = 0.10   # retries ≤ 10% of recent requests
    metrics_url: str = ""              # e.g. http://host:8000/metrics ("" disables)


_METRIC_LINE = re.compile(r"^(vllm:num_requests_waiting|vllm:gpu_cache_usage_perc)\s+([0-9.eE+-]+)")


def parse_vllm_metrics(text: str) -> dict:
    out = {}
    for line in text.splitlines():
        m = _METRIC_LINE.match(line.strip())
        if m:
            out[m.group(1)] = float(m.group(2))
    return out


class AdaptiveRateController:
    """Async concurrency gate. Use exactly like a semaphore:

        async with controller.slot():
            result = await call_llm(...)
            controller.record_latency(elapsed)

    On timeout/5xx: call controller.penalize(), then acquire a retry slot
    via `async with controller.retry_slot():` before retrying (this is where
    Tenacity integrates — its wait strategy sleeps, then the retry slot
    gates admission so backoff cannot stampede).
    """

    def __init__(self, config: ControllerConfig | None = None):
        self.cfg = config or ControllerConfig()
        self._limit = self.cfg.initial_concurrent
        self._active = 0
        self._cond = asyncio.Condition()
        self._latencies: deque = deque(maxlen=500)   # (timestamp, seconds)
        self._requests: deque = deque(maxlen=1000)   # timestamps
        self._retries: deque = deque(maxlen=1000)    # timestamps
        self._last_adjust = time.monotonic()
        self._congested_until = 0.0

    # ------------- public API -------------

    @property
    def limit(self) -> int:
        return self._limit

    def slot(self):
        return _Slot(self, is_retry=False)

    def retry_slot(self):
        return _Slot(self, is_retry=True)

    def record_latency(self, seconds: float) -> None:
        now = time.monotonic()
        self._latencies.append((now, seconds))
        self._requests.append(now)

    def penalize(self) -> None:
        """Immediate shared multiplicative decrease (timeout / 5xx / 429)."""
        self._decrease()
        self._congested_until = time.monotonic() + self.cfg.window_seconds

    def observe_metrics(self, metrics: dict) -> None:
        """Feed parsed /metrics; congestion triggers immediate decrease."""
        waiting = metrics.get("vllm:num_requests_waiting", 0.0)
        kv = metrics.get("vllm:gpu_cache_usage_perc", 0.0)
        if waiting > self.cfg.queue_depth_ceiling or kv > self.cfg.kv_cache_ceiling:
            self.penalize()

    async def metrics_loop(self, session) -> None:  # pragma: no cover - network
        """Optional background task: poll /metrics every few seconds.
        `session` is an aiohttp.ClientSession (or compatible)."""
        if not self.cfg.metrics_url:
            return
        while True:
            try:
                async with session.get(self.cfg.metrics_url, timeout=3) as resp:
                    self.observe_metrics(parse_vllm_metrics(await resp.text()))
            except Exception:
                pass  # metrics are advisory; latency signal still steers
            await asyncio.sleep(3)

    # ------------- internals -------------

    def p99(self) -> float:
        cutoff = time.monotonic() - 60
        recent = sorted(s for t, s in self._latencies if t >= cutoff)
        if not recent:
            return 0.0
        return recent[min(len(recent) - 1, int(len(recent) * 0.99))]

    def _retry_budget_available(self) -> bool:
        cutoff = time.monotonic() - 60
        recent_requests = sum(1 for t in self._requests if t >= cutoff)
        recent_retries = sum(1 for t in self._retries if t >= cutoff)
        allowed = max(1, int(recent_requests * self.cfg.retry_budget_ratio))
        return recent_retries < allowed

    def _decrease(self) -> None:
        self._limit = max(self.cfg.min_concurrent,
                          int(self._limit * self.cfg.decrease_factor))

    def _maybe_adjust(self) -> None:
        now = time.monotonic()
        if now - self._last_adjust < self.cfg.window_seconds:
            return
        self._last_adjust = now
        if now < self._congested_until:
            return  # cooling off after a penalty
        p99 = self.p99()
        if p99 > self.cfg.target_p99_seconds:
            self._decrease()
        elif p99 > 0:
            self._limit = min(self.cfg.max_concurrent,
                              self._limit + self.cfg.increase_step)

    async def _acquire(self, is_retry: bool) -> None:
        async with self._cond:
            while True:
                self._maybe_adjust()
                if self._active < self._limit and (
                        not is_retry or self._retry_budget_available()):
                    self._active += 1
                    if is_retry:
                        self._retries.append(time.monotonic())
                    return
                try:
                    await asyncio.wait_for(self._cond.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    pass  # re-check budget/limit each second

    async def _release(self) -> None:
        async with self._cond:
            self._active -= 1
            self._cond.notify_all()


class _Slot:
    def __init__(self, controller: AdaptiveRateController, is_retry: bool):
        self.controller = controller
        self.is_retry = is_retry

    async def __aenter__(self):
        await self.controller._acquire(self.is_retry)
        return self

    async def __aexit__(self, *exc):
        await self.controller._release()
        return False


# ---------------------------------------------------------------------------
# Tenacity integration sketch (import-guarded; pattern documented in audit doc)
# ---------------------------------------------------------------------------

def tenacity_wrapper(controller: AdaptiveRateController):  # pragma: no cover
    """Decorate your LLM call:

        @tenacity_wrapper(controller)
        async def call(...): ...

    First attempt uses a normal slot; each retry (a) penalizes the shared
    limit exactly once via retry_error_callback ordering, (b) sleeps with
    jittered exponential backoff, and (c) must acquire a budgeted retry slot,
    so retries can never exceed 10% of offered load — no cascade.
    """
    from tenacity import (AsyncRetrying, retry_if_exception_type,
                          stop_after_attempt, wait_random_exponential)

    def decorator(fn):
        async def wrapped(*args, **kwargs):
            attempt_no = 0
            async for attempt in AsyncRetrying(
                stop=stop_after_attempt(3),
                wait=wait_random_exponential(multiplier=1, max=20),
                retry=retry_if_exception_type((asyncio.TimeoutError, ConnectionError)),
                reraise=True,
            ):
                with attempt:
                    slot = controller.slot() if attempt_no == 0 else controller.retry_slot()
                    if attempt_no > 0:
                        controller.penalize()
                    attempt_no += 1
                    async with slot:
                        start = time.monotonic()
                        result = await fn(*args, **kwargs)
                        controller.record_latency(time.monotonic() - start)
                        return result
        return wrapped
    return decorator
