"""
src/llm_client.py — Async LLM clients: real (RunPod/vLLM) and mock.
===================================================================
Both expose the same one-method surface so the orchestrator is
client-agnostic:

    async def complete(system_prompt: str, user_prompt: str) -> str

The mock is deterministic, keyword-driven, and can inject the two failure
classes the pipeline must survive — malformed JSON (repairable) and
hallucinated quotes (triage-routable) — via magic markers in the source
text: MALFORMED_TRIGGER and HALLUCINATE_TRIGGER.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict

from src.config import MODEL_NAME, RUNPOD_API_KEY, RUNPOD_BASE_URL


class RunPodClient:
    """OpenAI-compatible chat client against a RunPod vLLM endpoint."""

    def __init__(self, model: str = MODEL_NAME):
        if not RUNPOD_BASE_URL or not RUNPOD_API_KEY:
            raise RuntimeError(
                "RUNPOD_BASE_URL and RUNPOD_API_KEY must be set (see .env.example)")
        from openai import AsyncOpenAI
        self.model = model
        self._client = AsyncOpenAI(base_url=RUNPOD_BASE_URL, api_key=RUNPOD_API_KEY)

    async def complete(self, system_prompt: str, user_prompt: str) -> str:
        response = await self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            response_format={"type": "json_object"},
        )
        content = response.choices[0].message.content
        if not content:
            raise ValueError("Empty message content from model")
        return content

    async def aclose(self) -> None:
        await self._client.close()


class MockLLMClient:
    """Deterministic stand-in for integration tests. No network, no cost.

    Behavior:
      * Tags by keyword (taper/veteran/kratom/abandon/stigma/illicit...).
      * Scope: 'national' or 'multi-state' in the chunk -> SCOPE_NATIONAL,
        otherwise SCOPE_LOCAL (when any content tag fired).
      * Quotes: the first sentence of the chunk, verbatim (so the
        verbatim-substring check passes by construction).
      * MALFORMED_TRIGGER in the chunk: the FIRST call for that chunk
        returns broken JSON (trailing comma + commentary); the retry
        succeeds — exercising the repair + retry path.
      * HALLUCINATE_TRIGGER in the chunk: the output includes one invented
        quote — exercising triage routing.
    """

    KEYWORD_TAGS = [
        (r"\btaper|dose (cut|reduction)|discontinu", "TAPER_HARM"),
        (r"\bveteran", "VETERAN_SUICIDE"),
        (r"\bguideline\b.*\b(critic|challeng|flaw)", "GUIDELINE_CRITIQUE"),
        (r"\bdefend(ed|s)? the guideline|officials defended", "GUIDELINE_DEFENSE"),
        (r"\bkratom|7-oh", "KRATOM_POLICY"),
        (r"\babandon|refused to fill|dismissed from the practice", "PATIENT_ABANDONMENT"),
        (r"\bstigma|drug-seek", "STIGMA"),
        (r"\billicit|street supply|gray-market", "DISPLACEMENT"),
        (r"\bsurveillance data|provisional data|data limitation", "DATA_LIMITATION"),
        (r"\bshe said|he said|her family|first-person|Ms\.|Mr\.", "PERSONAL_ACCOUNT"),
        (r"\bconflict(ing)? polic|agencies disagree|tension between", "POLICY_TENSION"),
    ]

    def __init__(self):
        self.calls = 0
        self._chunk_calls: dict = defaultdict(int)

    async def complete(self, system_prompt: str, user_prompt: str) -> str:
        self.calls += 1
        chunk = user_prompt.split("Classify this chunk:", 1)[-1].strip()
        key = hash(chunk)
        self._chunk_calls[key] += 1

        if "MALFORMED_TRIGGER" in chunk and self._chunk_calls[key] == 1:
            return ('Sure! Here is your classification:\n'
                    '{"tags": ["KRATOM_POLICY", "SCOPE_NATIONAL",], '
                    '"evidence_quotes": ["kratom"], "rationale": "r", '
                    '"confidence": 0.7,}\nHope this helps!')

        low = chunk.lower()
        tags = [tag for pattern, tag in self.KEYWORD_TAGS
                if re.search(pattern, low)]
        if tags:
            tags.append("SCOPE_NATIONAL" if re.search(r"national|multi-state", low)
                        else "SCOPE_LOCAL")

        first_sentence = re.split(r"(?<=[.!?])\s+", chunk)[0][:200]
        quotes = [first_sentence] if tags else []
        if "HALLUCINATE_TRIGGER" in chunk:
            quotes.append("officials confirmed the program was cancelled entirely")

        return json.dumps({
            "tags": tags,
            "evidence_quotes": quotes,
            "rationale": ("keyword-derived classification" if tags
                          else "no framework-relevant content"),
            "confidence": 0.8 if tags else 0.95,
        })

    async def aclose(self) -> None:  # interface parity
        return None
