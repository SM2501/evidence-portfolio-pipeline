"""
src/pipeline_orchestrator.py — Async producer-consumer extraction loop.
=======================================================================
Ties every module together:

  enqueue: read corpus -> content-hash identity -> archive text -> chunk
           count into the checkpoint store (dedupe is automatic).
  produce: for each claimed article, put every PENDING chunk on an
           asyncio.Queue (bounded -> backpressure).
  consume: N workers pull chunks; each LLM call passes through ONE shared
           AdaptiveRateController; output goes through extract_and_repair
           -> enforce_schema -> enforce_framework -> verify_quotes; every
           repair is recorded; every discrepancy is routed to the human
           triage queue; every result is checkpointed per chunk.
  finish:  fully extracted articles emit provisional graph rows
           (llm_provisional, whitelisted labels) to graph_out/ for the
           parameterized Neo4j loader.

Crash anywhere; re-run; execution resumes at the first unfinished chunk.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from pathlib import Path
from typing import List, Optional

from src import config
from src.checkpoint import CheckpointStore
from src.extraction_prompt import (build_system_prompt, build_user_prompt,
                                   enforce_framework, verify_quotes)
from src.json_repair import (E_EMPTY_TAGS, enforce_schema, extract_and_repair,
                             prompt_for_attempt)
from src.rate_controller import AdaptiveRateController, ControllerConfig
from src.text_cleaning import chunk_text, clean_text, count_tokens, detect_script

log = logging.getLogger("orchestrator")


# ---------------------------------------------------------------------------
# Corpus enqueue (idempotent; identity = content sha256)
# ---------------------------------------------------------------------------

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def enqueue_corpus(corpus_dir: str | Path, store: CheckpointStore) -> dict:
    """Read every .txt in corpus_dir; archive, dedupe, chunk-count."""
    config.ensure_dirs()
    stats = {"new": 0, "duplicates": 0, "routed_non_english": 0}
    for path in sorted(Path(corpus_dir).glob("*.txt")):
        raw = path.read_text(encoding="utf-8", errors="replace")
        cleaned = clean_text(raw)
        if not cleaned:
            continue
        report = detect_script(cleaned)
        if "route_to_multilingual_lane_or_skip" in report.recommendation:
            log.info("routing non-English/RTL article %s (%s)",
                     path.name, report.recommendation)
            stats["routed_non_english"] += 1
            continue
        article_id = sha256_text(cleaned)
        if not store.enqueue(article_id, source_url=path.name):
            stats["duplicates"] += 1
            continue
        (config.ARCHIVE_DIR / f"{article_id}.txt").write_text(
            cleaned, encoding="utf-8")
        chunks = chunk_text(cleaned, max_tokens=config.MAX_TOKENS_PER_CHUNK,
                            overlap_sentences=config.OVERLAP_SENTENCES,
                            pre_clean=False)
        store.set_chunk_count(article_id, len(chunks))
        stats["new"] += 1
    return stats


def _article_chunks(article_id: str) -> List:
    """Deterministic re-chunking from the archived text — the resume
    primitive needs chunk index N to mean the same text every run."""
    text = (config.ARCHIVE_DIR / f"{article_id}.txt").read_text(encoding="utf-8")
    return chunk_text(text, max_tokens=config.MAX_TOKENS_PER_CHUNK,
                      overlap_sentences=config.OVERLAP_SENTENCES, pre_clean=False)


# ---------------------------------------------------------------------------
# Triage routing
# ---------------------------------------------------------------------------

def route_to_triage(article_id: str, chunk_index: int, chunk_text_: str,
                    result: Optional[dict], codes: List[str]) -> None:
    entry = {
        "article_id": article_id,
        "chunk_index": chunk_index,
        "codes": codes,
        "result": result,
        "chunk_excerpt": chunk_text_[:500],
        "queued_at": time.time(),
        "status": "pending",
    }
    with config.TRIAGE_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Per-chunk processing (repair -> schema -> framework -> quotes -> checkpoint)
# ---------------------------------------------------------------------------

async def process_chunk(client, controller: AdaptiveRateController,
                        store: CheckpointStore, system_prompt: str,
                        article_id: str, chunk_index: int, text: str) -> None:
    base_user = build_user_prompt(text)
    last_error = "unknown"
    for attempt in range(config.MAX_LLM_ATTEMPTS):
        slot = controller.slot() if attempt == 0 else controller.retry_slot()
        if attempt > 0:
            controller.penalize()
        try:
            async with slot:
                start = time.monotonic()
                raw = await client.complete(
                    system_prompt, prompt_for_attempt(base_user, attempt))
                controller.record_latency(time.monotonic() - start)
        except Exception as exc:  # noqa: BLE001 — retried, then surfaced
            last_error = f"llm_call:{exc}"
            continue

        repaired = extract_and_repair(raw)
        if not repaired.ok:
            last_error = ";".join(repaired.errors)
            continue
        schema = enforce_schema(repaired.data, config.ALLOWED_TAG_STRINGS)
        if not schema.ok:
            last_error = ";".join(schema.errors)
            continue

        clean = schema.data
        triage_codes = [e for e in schema.errors]          # unknown-tag signals
        triage_codes += enforce_framework(clean)           # SCOPE rule
        hallucinated = verify_quotes(clean, text)
        if hallucinated:
            triage_codes.append(
                "E_QUOTE_NOT_IN_SOURCE:" + " | ".join(h[:80] for h in hallucinated))
            # Quotes that fail the verbatim check are quarantined out of the
            # payload; they exist only in the triage record.
            clean["evidence_quotes"] = [
                q for q in clean["evidence_quotes"] if q not in hallucinated]

        payload = {
            "result": clean,
            "triage_codes": triage_codes,
            "epistemic_status": "llm_provisional",
        }
        store.record_chunk(
            article_id, chunk_index, payload=payload,
            repairs=repaired.repairs + schema.repairs,
            tokens_in=count_tokens(system_prompt) + count_tokens(base_user),
            tokens_out=count_tokens(raw))
        if triage_codes:
            route_to_triage(article_id, chunk_index, text, clean, triage_codes)
        return

    store.record_chunk(article_id, chunk_index, payload=None,
                       error=last_error)
    route_to_triage(article_id, chunk_index, text, None,
                    [f"E_EXTRACTION_FAILED:{last_error[:200]}"])


# ---------------------------------------------------------------------------
# Graph emission (whitelisted labels; everything llm_provisional)
# ---------------------------------------------------------------------------

def emit_graph_rows(store: CheckpointStore, article_id: str) -> Path:
    nodes = [{
        "id": article_id,
        "label": "Article",
        "properties": {"epistemic_status": "provenance_anchor",
                       "created_by": "pipeline_orchestrator"},
        "_source_file": article_id,
    }]
    edges: List[dict] = []
    seen_tags: set = set()
    for chunk_index, payload in enumerate(store.article_results(article_id)):
        result = payload.get("result") or {}
        if not result.get("tags"):
            continue
        evidence_id = f"{article_id[:16]}:c{chunk_index}"
        nodes.append({
            "id": evidence_id,
            "label": "Evidence",
            "properties": {
                "tags": result["tags"],
                "evidence_quotes": result["evidence_quotes"],
                "rationale": result["rationale"],
                "confidence": result["confidence"],
                "triage_codes": payload.get("triage_codes", []),
                "epistemic_status": "llm_provisional",
            },
            "_source_file": article_id,
        })
        edges.append({"source": evidence_id, "target": article_id,
                      "type": "EXTRACTED_FROM",
                      "properties": {"epistemic_status": "provenance_anchor"},
                      "_source_file": article_id})
        for tag in result["tags"]:
            if tag not in seen_tags:
                seen_tags.add(tag)
                nodes.append({"id": tag, "label": "Tag",
                              "properties": {"definition": config.ALL_TAGS[tag],
                                             "epistemic_status": "provenance_anchor"},
                              "_source_file": article_id})
            edges.append({"source": evidence_id, "target": tag, "type": "TAGGED",
                          "properties": {"epistemic_status": "llm_provisional"},
                          "_source_file": article_id})
    out = config.GRAPH_DIR / f"{article_id}.json"
    out.write_text(json.dumps({"nodes": nodes, "edges": edges}, indent=2),
                   encoding="utf-8")
    return out


# ---------------------------------------------------------------------------
# The producer-consumer run loop
# ---------------------------------------------------------------------------

_SENTINEL = (None, None, None)


async def run_pipeline(corpus_dir: str | Path, client,
                       workers: int = config.WORKERS,
                       controller: Optional[AdaptiveRateController] = None,
                       max_articles: Optional[int] = None) -> dict:
    config.ensure_dirs()
    store = CheckpointStore(config.DB_PATH)
    enqueue_stats = enqueue_corpus(corpus_dir, store)

    controller = controller or AdaptiveRateController(
        ControllerConfig(initial_concurrent=min(16, workers * 2)))
    system_prompt = build_system_prompt()
    queue: asyncio.Queue = asyncio.Queue(maxsize=config.QUEUE_MAXSIZE)
    article_ids = store.claim_work(limit=max_articles or 1_000_000)

    async def producer() -> None:
        for article_id in article_ids:
            store.finish_article(article_id, state="extracting")
            chunks = _article_chunks(article_id)
            for idx in store.pending_chunks(article_id):
                await queue.put((article_id, idx, chunks[idx].text))
        for _ in range(workers):
            await queue.put(_SENTINEL)

    async def worker(worker_id: int) -> None:
        while True:
            article_id, idx, text = await queue.get()
            try:
                if article_id is None:
                    return
                await process_chunk(client, controller, store, system_prompt,
                                    article_id, idx, text)
            finally:
                queue.task_done()

    await asyncio.gather(producer(), *(worker(i) for i in range(workers)))

    finished = 0
    for article_id in article_ids:
        if store.pending_chunks(article_id):
            store.finish_article(article_id, state="chunked",
                                 error="incomplete: chunks pending")
            continue
        emit_graph_rows(store, article_id)
        store.finish_article(article_id, state="extracted")
        finished += 1

    summary = store.summary()
    summary.update(enqueue_stats)
    summary["articles_finished_this_run"] = finished
    summary["controller_limit_final"] = controller.limit
    return summary


def main() -> None:  # pragma: no cover - thin CLI
    import argparse
    from src.llm_client import MockLLMClient, RunPodClient
    parser = argparse.ArgumentParser(description="Run the extraction pipeline")
    parser.add_argument("corpus_dir")
    parser.add_argument("--workers", type=int, default=config.WORKERS)
    parser.add_argument("--mock", action="store_true",
                        help="Use the deterministic mock client (no network)")
    parser.add_argument("--max-articles", type=int, default=None)
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s")
    client = MockLLMClient() if args.mock else RunPodClient()
    summary = asyncio.run(run_pipeline(args.corpus_dir, client,
                                       workers=args.workers,
                                       max_articles=args.max_articles))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
