"""
src/verify.py — Offline human-in-the-loop review with signed decisions.
=======================================================================
The one door through which machine output becomes reviewable evidence.
Every decision requires a typed rationale and is HMAC-SHA256 signed into
the hash-chained verification log (see src/audit_verifier.py for the
threat model: modification, forgery, deletion, insertion, and — with an
externally anchored head — truncation are all detectable).

The signing key lives at ~/.pipeline/audit_key by default. Keep it OFF
the extraction host if the two ever separate; the key is what makes
history unforgeable by a compromised pipeline.

Commands (run from repo root):
    python -m src.verify keygen
    python -m src.verify queue                 # list pending triage items
    python -m src.verify review                # interactive decision loop
    python -m src.verify check [--anchor HEX]  # verify log integrity
    python -m src.verify head                  # print head hash to anchor externally
    python -m src.verify status
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import List

from src import config
from src.audit_verifier import SignedVerificationLog, verify_log

ACTIONS = {"a": "approve", "r": "reject", "m": "modify", "f": "flag_for_recheck"}


# ---------------------------------------------------------------------------
# Triage queue helpers (JSONL; status flipped in place on decision)
# ---------------------------------------------------------------------------

def _load_triage() -> List[dict]:
    if not config.TRIAGE_PATH.exists():
        return []
    return [json.loads(line) for line in
            config.TRIAGE_PATH.read_text(encoding="utf-8").splitlines() if line]


def _save_triage(items: List[dict]) -> None:
    with config.TRIAGE_PATH.open("w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


def _pending(items: List[dict]) -> List[int]:
    return [i for i, item in enumerate(items) if item.get("status") == "pending"]


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_keygen(_args) -> None:
    key_path = config.AUDIT_KEY_PATH
    if key_path.exists():
        sys.exit(f"refusing to overwrite existing key at {key_path}")
    key_path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(key_path.parent, 0o700)
    import secrets
    key_path.write_bytes(secrets.token_hex(32).encode())
    os.chmod(key_path, 0o600)
    print(f"signing key written to {key_path}")
    print("If extraction ever runs on a different machine, keep this key off it.")


def cmd_queue(_args) -> None:
    items = _load_triage()
    pending = _pending(items)
    print(f"{len(pending)} pending / {len(items)} total triage items")
    for i in pending[:30]:
        item = items[i]
        print(f"  [{i}] {item['article_id'][:12]}:c{item['chunk_index']}  "
              f"{'; '.join(item['codes'])[:90]}")
    if len(pending) > 30:
        print(f"  … and {len(pending) - 30} more")


def cmd_review(args) -> None:
    if not config.AUDIT_KEY_PATH.exists():
        sys.exit("no signing key — run: python -m src.verify keygen")
    reviewer = args.reviewer or input("reviewer id (initials/email)> ").strip()
    if not reviewer:
        sys.exit("a reviewer identity is required — decisions must be attributable")
    vlog = SignedVerificationLog(config.VERIFICATION_LOG, config.AUDIT_KEY_PATH)
    items = _load_triage()
    pending = _pending(items)
    if not pending:
        print("Nothing pending.")
        return
    print(f"{len(pending)} pending. For each: (a)pprove (r)eject (m)odify "
          f"(f)lag (s)kip (q)uit\n")
    for i in pending:
        item = items[i]
        result = item.get("result") or {}
        print("=" * 72)
        print(f"[{i}] article {item['article_id'][:16]}  chunk {item['chunk_index']}")
        print(f"codes:  {'; '.join(item['codes'])}")
        print(f"tags:   {result.get('tags')}")
        for q in result.get("evidence_quotes", []):
            print(f"quote:  {q!r}")
        print(f"chunk:  {item['chunk_excerpt'][:400]}")
        choice = input("decision [a/r/m/f/s/q]> ").strip().lower()
        if choice == "q":
            break
        if choice == "s" or choice not in ACTIONS:
            continue
        changes = {}
        if choice == "m":
            new_tags = input("corrected tags (comma-separated)> ").strip()
            changes = {"tags": {"old": result.get("tags"),
                                "new": [t.strip() for t in new_tags.split(",")
                                        if t.strip()]}}
        print("Rationale — what you checked and why. (Your testimony; type it.)")
        rationale = input("rationale> ").strip()
        try:
            vlog.append(
                reviewer_id=reviewer,
                action=ACTIONS[choice],
                article_id=item["article_id"],
                claim_ref=f"chunk[{item['chunk_index']}]",
                evidence_text=json.dumps(result, sort_keys=True),
                rationale=rationale,
                changes=changes,
            )
        except ValueError as exc:
            print(f"not recorded: {exc}")
            continue
        item["status"] = ACTIONS[choice]
        _save_triage(items)
        print(f"recorded + signed: {ACTIONS[choice]}")
    print(f"\nsession head hash (anchor this outside the pipeline): {vlog.head()}")


def cmd_check(args) -> None:
    report = verify_log(config.VERIFICATION_LOG, config.AUDIT_KEY_PATH,
                        anchored_head=args.anchor)
    print(f"entries: {report.entries}")
    for problem in report.problems:
        print(f"  !! {problem}")
    print("VERDICT:", "INTACT" if report.ok else "TAMPERING DETECTED")
    sys.exit(0 if report.ok else 2)


def cmd_head(_args) -> None:
    vlog = SignedVerificationLog(config.VERIFICATION_LOG, config.AUDIT_KEY_PATH)
    print(vlog.head())


def cmd_status(_args) -> None:
    from src.checkpoint import CheckpointStore
    items = _load_triage()
    decided = [i for i in items if i.get("status") != "pending"]
    print(json.dumps({
        "pipeline": CheckpointStore(config.DB_PATH).summary(),
        "triage": {"total": len(items), "pending": len(items) - len(decided),
                   "decided": len(decided)},
    }, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Human verification CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("keygen")
    sub.add_parser("queue")
    review = sub.add_parser("review")
    review.add_argument("--reviewer", default=None)
    check = sub.add_parser("check")
    check.add_argument("--anchor", default=None)
    sub.add_parser("head")
    sub.add_parser("status")
    args = parser.parse_args()
    {"keygen": cmd_keygen, "queue": cmd_queue, "review": cmd_review,
     "check": cmd_check, "head": cmd_head, "status": cmd_status}[args.cmd](args)


if __name__ == "__main__":
    main()
