"""
audit_verifier.py — Signed verification log + standalone tamper detector.
=========================================================================
Section 4 of the pipeline redesign.

The honest answer to "can a compromised script silently alter a past
decision?" for a plain hash-chained log is YES: an unkeyed chain proves only
internal consistency. Any process that can write the file can rewrite an
entry and recompute every subsequent hash in milliseconds. The chain detects
casual editing, not adversarial rewriting.

Three defenses, layered (each closes what the previous cannot):

  1. HMAC-signed entries. Every entry is signed with a key that the pipeline
     host does NOT hold — the signing key lives with the human reviewer
     (e.g., a key file on a USB stick / separate machine used only during
     verification sessions). A compromised extraction box can then corrupt
     future entries but cannot forge or rewrite signed history.
  2. Content addressing. Each entry embeds the sha256 of the exact evidence
     text it approves, so a decision cannot be silently re-pointed at
     different evidence.
  3. External anchoring. After each session, the head hash (8 bytes of
     entropy is plenty) is recorded somewhere the pipeline cannot write:
     a notebook, an email to yourself, a git repo on another machine. The
     verifier checks the log against any anchored head, which converts
     "rewrite the file" into "rewrite the file AND the outside world."

Usage:
    python audit_verifier.py keygen  --key reviewer.key
    python audit_verifier.py verify  --log verification_log.jsonl --key reviewer.key
    python audit_verifier.py verify  --log verification_log.jsonl --key reviewer.key \
        --anchor 9f3a1c2b0d4e5f66
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import secrets
import sys
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

GENESIS = "GENESIS"
VALID_ACTIONS = {"approve", "reject", "modify", "flag_for_recheck"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _canonical(obj: dict) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class VerificationEntry:
    """One human decision about one piece of extracted evidence."""
    seq: int                      # strictly increasing; gaps = deletions
    prev_hash: str                # chain link
    timestamp: str                # UTC ISO-8601
    reviewer_id: str              # human identifier (initials/email)
    action: str                   # approve | reject | modify | flag_for_recheck
    article_id: str               # content hash or slug of source article
    claim_ref: str                # e.g. "load_bearing_claims[1]" or tag name
    evidence_sha256: str          # hash of the EXACT evidence text decided on
    changes: dict = field(default_factory=dict)   # for modify: {"field": {"old_sha256":..., "new_sha256":...}}
    rationale: str = ""           # required, human-typed
    entry_hash: str = ""          # sha256 of canonical payload (excl. hash+sig)
    signature: str = ""           # HMAC-SHA256(key, entry_hash || prev_hash)

    def payload(self) -> dict:
        d = asdict(self)
        d.pop("entry_hash"), d.pop("signature")
        return d


class SignedVerificationLog:
    """Append-only JSONL of signed verification entries."""

    def __init__(self, log_path: str | Path, key_path: str | Path):
        self.path = Path(log_path)
        self.key = Path(key_path).read_bytes().strip()
        self._last_hash, self._last_seq = self._tail()

    def _tail(self):
        if not self.path.exists() or self.path.stat().st_size == 0:
            return GENESIS, -1
        last = self.path.read_text(encoding="utf-8").rstrip("\n").rsplit("\n", 1)[-1]
        e = json.loads(last)
        return e["entry_hash"], e["seq"]

    def append(self, *, reviewer_id: str, action: str, article_id: str,
               claim_ref: str, evidence_text: str, rationale: str,
               changes: Optional[dict] = None) -> VerificationEntry:
        if action not in VALID_ACTIONS:
            raise ValueError(f"action must be one of {sorted(VALID_ACTIONS)}")
        if not rationale.strip():
            raise ValueError("rationale is required — a decision with no "
                             "reason is not auditable")
        entry = VerificationEntry(
            seq=self._last_seq + 1,
            prev_hash=self._last_hash,
            timestamp=_now(),
            reviewer_id=reviewer_id,
            action=action,
            article_id=article_id,
            claim_ref=claim_ref,
            evidence_sha256=_sha256(evidence_text),
            changes=changes or {},
            rationale=rationale,
        )
        entry.entry_hash = _sha256(_canonical(entry.payload()))
        entry.signature = hmac.new(
            self.key, (entry.entry_hash + entry.prev_hash).encode(), hashlib.sha256
        ).hexdigest()
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(entry)) + "\n")
        self._last_hash, self._last_seq = entry.entry_hash, entry.seq
        return entry

    def head(self) -> str:
        """Anchor this externally after every session (first 16 hex chars)."""
        return self._last_hash[:16]


# ---------------------------------------------------------------------------
# Standalone verifier — run it on a machine the pipeline can't write to
# ---------------------------------------------------------------------------

@dataclass
class VerifyReport:
    ok: bool
    entries: int
    problems: List[str]


def verify_log(log_path: str | Path, key_path: str | Path,
               anchored_head: Optional[str] = None) -> VerifyReport:
    """Detects: modified entries (hash mismatch), forged entries (bad HMAC),
    deletions (seq gaps), insertions/reordering (chain breaks), truncation
    (anchored head not found at tail)."""
    problems: List[str] = []
    key = Path(key_path).read_bytes().strip()
    path = Path(log_path)
    if not path.exists():
        return VerifyReport(anchored_head is None, 0,
                            ["log missing but an anchored head exists"]
                            if anchored_head else [])
    prev_hash, prev_seq = GENESIS, -1
    n = 0
    last_hash = GENESIS
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            problems.append(f"line {lineno}: unparseable (corruption)")
            continue
        n += 1
        payload = {k: v for k, v in e.items() if k not in ("entry_hash", "signature")}
        recomputed = _sha256(_canonical(payload))
        if recomputed != e.get("entry_hash"):
            problems.append(f"seq {e.get('seq')}: entry MODIFIED (hash mismatch)")
        expected_sig = hmac.new(
            key, (e.get("entry_hash", "") + e.get("prev_hash", "")).encode(),
            hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_sig, e.get("signature", "")):
            problems.append(f"seq {e.get('seq')}: signature INVALID (forged or wrong key)")
        if e.get("prev_hash") != prev_hash:
            problems.append(f"seq {e.get('seq')}: chain BREAK (insertion/reorder/rewrite)")
        if e.get("seq") != prev_seq + 1:
            problems.append(f"seq {e.get('seq')}: sequence gap after {prev_seq} (deletion)")
        if e.get("timestamp", "") < "1970":
            problems.append(f"seq {e.get('seq')}: implausible timestamp")
        prev_hash, prev_seq = e.get("entry_hash", ""), e.get("seq", prev_seq + 1)
        last_hash = prev_hash
    if anchored_head and not last_hash.startswith(anchored_head):
        problems.append("anchored head not at tail: log TRUNCATED or REWRITTEN "
                        "after the anchor was recorded")
    return VerifyReport(not problems, n, problems)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description="Signed verification log tools")
    sub = p.add_subparsers(dest="cmd", required=True)
    kg = sub.add_parser("keygen")
    kg.add_argument("--key", required=True)
    v = sub.add_parser("verify")
    v.add_argument("--log", required=True)
    v.add_argument("--key", required=True)
    v.add_argument("--anchor", default=None,
                   help="Externally recorded head hash prefix to check against")
    args = p.parse_args()

    if args.cmd == "keygen":
        path = Path(args.key)
        if path.exists():
            sys.exit(f"refusing to overwrite existing key {path}")
        path.write_bytes(secrets.token_hex(32).encode())
        os.chmod(path, 0o600)
        print(f"key written to {path} — store it OFF the pipeline host")
        return

    report = verify_log(args.log, args.key, args.anchor)
    print(f"entries: {report.entries}")
    for prob in report.problems:
        print(f"  !! {prob}")
    print("VERDICT:", "INTACT" if report.ok else "TAMPERING DETECTED")
    sys.exit(0 if report.ok else 2)


if __name__ == "__main__":
    main()
