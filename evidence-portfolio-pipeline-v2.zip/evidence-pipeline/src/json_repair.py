"""
json_repair.py — Extraction, repair, and schema enforcement for LLM output.
============================================================================
Section 2 of the pipeline redesign.

Strategy, in order of increasing invasiveness (every repair is RECORDED so
downstream consumers know how mangled the original was):

  1. Parse as-is.
  2. Strip Markdown fences / leading commentary; extract the first balanced
     JSON object via a brace-counting scan (greedy, string-aware).
  3. Mechanical repairs: trailing commas, unquoted keys, single-quoted
     strings, truncated braces/brackets, control characters.
  4. If the optional `json_repair` PyPI library is installed, use it as a
     final fallback.

Duplicate keys keep the FIRST occurrence (models usually emit the real value
first, then hallucinate a duplicate). Unknown extra keys (e.g. "explanation")
are dropped at schema-enforcement time, not treated as failures.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Error codes for human review routing
# ---------------------------------------------------------------------------

E_NO_JSON_FOUND = "E_NO_JSON_FOUND"
E_UNREPAIRABLE = "E_UNREPAIRABLE"
E_MISSING_FIELD = "E_MISSING_FIELD"
E_BAD_TYPE = "E_BAD_TYPE"
E_UNKNOWN_TAG = "E_UNKNOWN_TAG"
E_EMPTY_TAGS = "E_EMPTY_TAGS"
E_CONFIDENCE_RANGE = "E_CONFIDENCE_RANGE"


@dataclass
class RepairResult:
    ok: bool
    data: Optional[dict]
    repairs: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Step 2: balanced-object extraction (string-aware brace scan)
# ---------------------------------------------------------------------------

_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


def _extract_candidate(text: str) -> Optional[str]:
    fenced = _FENCE.search(text)
    if fenced:
        text = fenced.group(1)
    start = text.find("{")
    if start == -1:
        return None
    depth, in_string, escape = 0, False, False
    for i in range(start, len(text)):
        c = text[i]
        if in_string:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                in_string = False
        else:
            if c == '"':
                in_string = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
    return text[start:]  # truncated object — repairs will close it


# ---------------------------------------------------------------------------
# Step 3: mechanical repairs
# ---------------------------------------------------------------------------

_TRAILING_COMMA = re.compile(r",(\s*[}\]])")
_UNQUOTED_KEY = re.compile(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)")
_SINGLE_QUOTED = re.compile(r"'([^'\\]*(?:\\.[^'\\]*)*)'")
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _mechanical_repairs(candidate: str, repairs: List[str]) -> str:
    fixed = _CONTROL_CHARS.sub("", candidate)
    if fixed != candidate:
        repairs.append("stripped_control_chars")
    new = _TRAILING_COMMA.sub(r"\1", fixed)
    if new != fixed:
        repairs.append("removed_trailing_commas")
    fixed = new
    new = _UNQUOTED_KEY.sub(r'\1"\2"\3', fixed)
    if new != fixed:
        repairs.append("quoted_unquoted_keys")
    fixed = new
    # Balance truncated structures (string-aware count)
    depth_obj = depth_arr = 0
    in_string = escape = False
    for c in fixed:
        if in_string:
            if escape:
                escape = False
            elif c == "\\":
                escape = True
            elif c == '"':
                in_string = False
        else:
            if c == '"':
                in_string = True
            elif c == "{":
                depth_obj += 1
            elif c == "}":
                depth_obj -= 1
            elif c == "[":
                depth_arr += 1
            elif c == "]":
                depth_arr -= 1
    if in_string:
        fixed += '"'
        repairs.append("closed_unterminated_string")
    if depth_arr > 0 or depth_obj > 0:
        # Close in plausible nesting order: arrays first, then objects.
        fixed = fixed.rstrip().rstrip(",")
        fixed += "]" * depth_arr + "}" * depth_obj
        repairs.append(f"closed_truncated_structures(arr={depth_arr},obj={depth_obj})")
    return fixed


def _dedupe_pairs(pairs):
    """Keep FIRST occurrence of duplicate keys."""
    out: Dict[str, Any] = {}
    for k, v in pairs:
        if k not in out:
            out[k] = v
    return out


def extract_and_repair(raw_text: str) -> RepairResult:
    """Full pipeline: extract → parse → repair → parse → library fallback."""
    repairs: List[str] = []
    candidate = _extract_candidate(raw_text or "")
    if candidate is None:
        return RepairResult(False, None, repairs, [E_NO_JSON_FOUND])
    if candidate != (raw_text or "").strip():
        repairs.append("extracted_embedded_object")

    for attempt in ("as_is", "mechanical", "single_quotes"):
        try:
            return RepairResult(True,
                                json.loads(candidate, object_pairs_hook=_dedupe_pairs),
                                repairs, [])
        except json.JSONDecodeError:
            if attempt == "as_is":
                candidate = _mechanical_repairs(candidate, repairs)
            elif attempt == "mechanical":
                new = _SINGLE_QUOTED.sub(lambda m: json.dumps(m.group(1)), candidate)
                if new != candidate:
                    repairs.append("converted_single_quotes")
                candidate = new

    try:  # optional heavy-duty fallback
        from json_repair import repair_json  # type: ignore
        data = json.loads(repair_json(candidate))
        repairs.append("json_repair_library")
        return RepairResult(True, data, repairs, [])
    except Exception:
        return RepairResult(False, None, repairs, [E_UNREPAIRABLE])


# ---------------------------------------------------------------------------
# Schema enforcement for the 12-tag extraction contract
# ---------------------------------------------------------------------------

REQUIRED_FIELDS = ("tags", "evidence_quotes", "rationale", "confidence")


def enforce_schema(data: dict, allowed_tags: List[str]) -> RepairResult:
    """Coerce and validate the extraction contract. Unknown extra keys are
    silently dropped; genuine problems come back as routed error codes."""
    repairs: List[str] = []
    errors: List[str] = []
    clean: Dict[str, Any] = {}

    for f in REQUIRED_FIELDS:
        if f not in data:
            errors.append(f"{E_MISSING_FIELD}:{f}")
    if errors:
        return RepairResult(False, None, repairs, errors)

    tags = data["tags"]
    if isinstance(tags, str):
        tags = [t.strip() for t in re.split(r"[,;]", tags) if t.strip()]
        repairs.append("coerced_tags_string_to_list")
    if not isinstance(tags, list):
        return RepairResult(False, None, repairs, [f"{E_BAD_TYPE}:tags"])
    unknown = [t for t in tags if t not in allowed_tags]
    tags = [t for t in tags if t in allowed_tags]
    if unknown:
        errors.append(f"{E_UNKNOWN_TAG}:{','.join(map(str, unknown[:5]))}")
    if not tags:
        errors.append(E_EMPTY_TAGS)
    clean["tags"] = tags

    quotes = data["evidence_quotes"]
    if isinstance(quotes, str):
        quotes = [quotes]
        repairs.append("coerced_quotes_string_to_list")
    if not isinstance(quotes, list) or not all(isinstance(q, str) for q in quotes):
        return RepairResult(False, None, repairs, [f"{E_BAD_TYPE}:evidence_quotes"])
    clean["evidence_quotes"] = [q.strip() for q in quotes if q.strip()]

    clean["rationale"] = str(data["rationale"]).strip()

    try:
        conf = float(data["confidence"])
    except (TypeError, ValueError):
        return RepairResult(False, None, repairs, [f"{E_BAD_TYPE}:confidence"])
    if not 0.0 <= conf <= 1.0:
        if 0.0 <= conf <= 100.0:
            conf = conf / 100.0
            repairs.append("rescaled_confidence_percent")
        else:
            return RepairResult(False, None, repairs, [E_CONFIDENCE_RANGE])
    clean["confidence"] = round(conf, 3)

    # E_EMPTY_TAGS / E_UNKNOWN_TAG are review-routing signals, not hard fails:
    ok = not any(e.startswith((E_BAD_TYPE, E_MISSING_FIELD, E_CONFIDENCE_RANGE))
                 for e in errors)
    return RepairResult(ok, clean if ok else None, repairs, errors)


# ---------------------------------------------------------------------------
# Prompt mutation for the retry loop (max 2 retries by design)
# ---------------------------------------------------------------------------

RETRY_SUFFIXES = [
    "",  # attempt 0: original prompt
    "\n\nREMINDER: Output ONLY the JSON object. No commentary, no markdown "
    "fences, no text before or after the opening and closing braces.",
    "\n\nSTRICT MODE: Your previous output was not valid JSON. Respond with "
    "exactly one minified JSON object on a single line, matching the schema, "
    "and nothing else. Do not explain. Do not apologize. Begin with '{'.",
]


def prompt_for_attempt(base_user_prompt: str, attempt: int) -> str:
    """attempt: 0 = first try, 1 = first retry, 2 = last retry."""
    idx = min(attempt, len(RETRY_SUFFIXES) - 1)
    return base_user_prompt + RETRY_SUFFIXES[idx]
