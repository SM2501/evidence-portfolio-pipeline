# Manual Integration Test Plan — Mock LLM, 3-Document Corpus

Ten steps, run from the repo root, no network or GPU required. Expected
observations are stated for each step; any deviation is a finding.

**Step 1 — Environment.** `python -m venv .venv && source .venv/bin/activate
&& pip install -r requirements.txt`. Then `python -m src.test_redesign` and
confirm `ALL 18 CHECKS PASSED`. This proves module wiring before you test
workflow.

**Step 2 — Build the corpus.** Create `corpus/` with three files.
`doc1.txt`: a local taper-harm narrative ("The county clinic began a rapid
taper program... Ms. Rivera said the dose reduction left her in withdrawal...
her pharmacist refused to fill the remainder."). `doc2.txt`: begins with the
literal token `MALFORMED_TRIGGER`, then a national kratom story ("National
regulators opened a multi-state review of kratom products..."). `doc3.txt`:
begins with `HALLUCINATE_TRIGGER`, then a veteran pain-care account. The two
trigger tokens instruct the mock client to emit, respectively, broken JSON on
first attempt and one invented evidence quote.

**Step 3 — First extraction run.** `python -m src.pipeline_orchestrator
corpus/ --mock --workers 3`. Expect a JSON summary with
`articles_by_state.extracted: 3`, `new: 3`, and `chunks_needing_repair >= 1`
(doc2's mangled reply, repaired in-flight and recorded).

**Step 4 — Inspect checkpoints.** `sqlite3 data/pipeline_state.db "SELECT
state, COUNT(*) FROM articles GROUP BY state;"` → `extracted|3`. Then
`SELECT article_id, chunk_index, repairs FROM chunk_results WHERE repairs !=
'[]';` → at least one row naming the repairs applied to doc2 (e.g.
`removed_trailing_commas`, `extracted_embedded_object`).

**Step 5 — Inspect triage.** `python -m src.verify queue`. Expect at least
one pending item whose codes include `E_QUOTE_NOT_IN_SOURCE:` for doc3 — the
invented quote was quarantined out of the stored payload and routed here.
Confirm with `cat data/triage_queue.jsonl` that the hallucinated text appears
only in the triage record's codes, not in `result.evidence_quotes`.

**Step 6 — Inspect the graph output.** `ls data/graph_out/` → three JSON
files named by content hash. Open one: every node label is one of
`Article|Evidence|Tag`; every Evidence node carries `epistemic_status:
llm_provisional`, verbatim quotes, and a tag set that includes exactly one
`SCOPE_*`; every Evidence node has an `EXTRACTED_FROM` edge to its Article
and `TAGGED` edges to Tag nodes drawn only from the 12-tag vocabulary.

**Step 7 — Idempotent resume.** Re-run the exact Step 3 command. Expect
`duplicates: 3`, `new: 0`, and — the important part — the run completes
near-instantly because zero chunks are pending. Nothing is re-extracted,
nothing re-spent.

**Step 8 — Crash-resume.** Simulate a mid-run crash by deleting one chunk's
checkpoint: `sqlite3 data/pipeline_state.db "DELETE FROM chunk_results WHERE
rowid = (SELECT rowid FROM chunk_results LIMIT 1); UPDATE articles SET
state='chunked' WHERE article_id = (SELECT article_id FROM articles LIMIT
1);"`. Re-run Step 3. Expect exactly the one missing chunk to be recomputed
(one additional mock call — visible because the run logs one worker action)
and the article to return to `extracted`.

**Step 9 — Signed human review.** `python -m src.verify keygen` (writes
`~/.pipeline/audit_key`, mode 0600), then `python -m src.verify review`.
For the doc3 triage item: observe that the interface shows the codes, the
model's tags, surviving quotes, and the source excerpt; choose `r` (reject);
observe that an empty rationale is refused; type a real rationale; note the
session head hash printed at the end and write it down somewhere outside the
repo — that is your external anchor.

**Step 10 — Tamper detection.** First, `python -m src.verify check --anchor
<hash from step 9>` → `VERDICT: INTACT`. Now edit `data/verification_log.jsonl`
in a text editor: change one character of the rationale. Re-run the check →
`VERDICT: TAMPERING DETECTED` with the modified seq named. Restore the file
(or delete the last line and observe the anchor catch the truncation).
This closes the loop: the pipeline you just ran cannot quietly rewrite the
decisions you just signed.

A clean pass of steps 1–10 demonstrates: wiring, chunk-level checkpointing
and exact resume, JSON repair with metrics, verbatim-quote triage routing,
SCOPE enforcement, whitelisted provisional graph emission, idempotency,
mandatory rationales, cryptographic signing, and tamper detection — the full
contract of the architecture, on three documents, in about ten minutes.
